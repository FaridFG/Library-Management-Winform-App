﻿namespace LibraryManagement
{
    partial class LibEmployees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LibEmployees));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelEmployeesTop = new System.Windows.Forms.Panel();
            this.lblUser = new System.Windows.Forms.Label();
            this.minimizeEmployeePage = new System.Windows.Forms.Label();
            this.closeEmployeePage = new System.Windows.Forms.Label();
            this.panelEmployeeMenu = new System.Windows.Forms.Panel();
            this.btnEmployeeSearch = new Guna.UI.WinForms.GunaAdvenceButton();
            this.btnEmployeeReturnBook = new Guna.UI.WinForms.GunaAdvenceButton();
            this.btnEmployeeRentBook = new Guna.UI.WinForms.GunaAdvenceButton();
            this.btnEmployeeBooks = new Guna.UI.WinForms.GunaAdvenceButton();
            this.panelEmployeeBody = new System.Windows.Forms.Panel();
            this.pnlBookReturn = new System.Windows.Forms.Panel();
            this.btnEmployeeReturnBooks = new Guna.UI.WinForms.GunaButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnReturnList = new System.Windows.Forms.CheckedListBox();
            this.cmbEmployeeReturnCustomer = new Guna.UI.WinForms.GunaComboBox();
            this.pnlSearchBook = new System.Windows.Forms.Panel();
            this.btnEmployeeSearchBooks = new Guna.UI.WinForms.GunaAdvenceButton();
            this.dgvEmployeeSearchResult = new Guna.UI.WinForms.GunaDataGridView();
            this.txtEmployeeSearch = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlEmployeeRents = new System.Windows.Forms.Panel();
            this.AddBooks = new Guna.UI.WinForms.GunaButton();
            this.numBook = new Guna.UI.WinForms.GunaNumeric();
            this.label7 = new System.Windows.Forms.Label();
            this.btnEmployeeRentConfirm = new Guna.UI.WinForms.GunaButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lstAddedBooks = new System.Windows.Forms.CheckedListBox();
            this.cmbEmployeeCustomerNames = new Guna.UI.WinForms.GunaComboBox();
            this.cmbEmployeeRentBook = new Guna.UI.WinForms.GunaComboBox();
            this.pnlEmployeeBooks = new System.Windows.Forms.Panel();
            this.dgvEmployeeBooks = new Guna.UI.WinForms.GunaDataGridView();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.cmbReturnDay = new Guna.UI.WinForms.GunaComboBox();
            this.cmbReturnMonth = new Guna.UI.WinForms.GunaComboBox();
            this.cmbReturnYear = new Guna.UI.WinForms.GunaComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbReturnDate = new Guna.UI.WinForms.GunaComboBox();
            this.panelEmployeesTop.SuspendLayout();
            this.panelEmployeeMenu.SuspendLayout();
            this.panelEmployeeBody.SuspendLayout();
            this.pnlBookReturn.SuspendLayout();
            this.pnlSearchBook.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeeSearchResult)).BeginInit();
            this.pnlEmployeeRents.SuspendLayout();
            this.pnlEmployeeBooks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeeBooks)).BeginInit();
            this.SuspendLayout();
            // 
            // panelEmployeesTop
            // 
            this.panelEmployeesTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.panelEmployeesTop.Controls.Add(this.lblUser);
            this.panelEmployeesTop.Controls.Add(this.minimizeEmployeePage);
            this.panelEmployeesTop.Controls.Add(this.closeEmployeePage);
            this.panelEmployeesTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEmployeesTop.Location = new System.Drawing.Point(0, 0);
            this.panelEmployeesTop.Name = "panelEmployeesTop";
            this.panelEmployeesTop.Size = new System.Drawing.Size(1396, 97);
            this.panelEmployeesTop.TabIndex = 0;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.White;
            this.lblUser.Location = new System.Drawing.Point(29, 23);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 39);
            this.lblUser.TabIndex = 46;
            this.lblUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // minimizeEmployeePage
            // 
            this.minimizeEmployeePage.AutoSize = true;
            this.minimizeEmployeePage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimizeEmployeePage.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimizeEmployeePage.ForeColor = System.Drawing.Color.White;
            this.minimizeEmployeePage.Location = new System.Drawing.Point(1248, 1);
            this.minimizeEmployeePage.Name = "minimizeEmployeePage";
            this.minimizeEmployeePage.Size = new System.Drawing.Size(59, 67);
            this.minimizeEmployeePage.TabIndex = 45;
            this.minimizeEmployeePage.Text = "_";
            this.minimizeEmployeePage.Click += new System.EventHandler(this.minimizeEmployeePage_Click);
            // 
            // closeEmployeePage
            // 
            this.closeEmployeePage.AutoSize = true;
            this.closeEmployeePage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeEmployeePage.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeEmployeePage.ForeColor = System.Drawing.Color.White;
            this.closeEmployeePage.Location = new System.Drawing.Point(1304, 9);
            this.closeEmployeePage.Name = "closeEmployeePage";
            this.closeEmployeePage.Size = new System.Drawing.Size(64, 67);
            this.closeEmployeePage.TabIndex = 44;
            this.closeEmployeePage.Text = "X";
            this.closeEmployeePage.Click += new System.EventHandler(this.closeEmployeePage_Click);
            // 
            // panelEmployeeMenu
            // 
            this.panelEmployeeMenu.Controls.Add(this.btnEmployeeSearch);
            this.panelEmployeeMenu.Controls.Add(this.btnEmployeeReturnBook);
            this.panelEmployeeMenu.Controls.Add(this.btnEmployeeRentBook);
            this.panelEmployeeMenu.Controls.Add(this.btnEmployeeBooks);
            this.panelEmployeeMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEmployeeMenu.Location = new System.Drawing.Point(0, 97);
            this.panelEmployeeMenu.Name = "panelEmployeeMenu";
            this.panelEmployeeMenu.Size = new System.Drawing.Size(1396, 70);
            this.panelEmployeeMenu.TabIndex = 1;
            // 
            // btnEmployeeSearch
            // 
            this.btnEmployeeSearch.Animated = true;
            this.btnEmployeeSearch.AnimationHoverSpeed = 0.8F;
            this.btnEmployeeSearch.AnimationSpeed = 0.8F;
            this.btnEmployeeSearch.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnEmployeeSearch.BaseColor = System.Drawing.Color.White;
            this.btnEmployeeSearch.BorderColor = System.Drawing.Color.Black;
            this.btnEmployeeSearch.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton;
            this.btnEmployeeSearch.CheckedBaseColor = System.Drawing.Color.White;
            this.btnEmployeeSearch.CheckedBorderColor = System.Drawing.Color.Black;
            this.btnEmployeeSearch.CheckedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearch.CheckedImage = null;
            this.btnEmployeeSearch.CheckedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmployeeSearch.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEmployeeSearch.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEmployeeSearch.FocusedColor = System.Drawing.Color.Empty;
            this.btnEmployeeSearch.Font = new System.Drawing.Font("Lucida Sans Unicode", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearch.Image = null;
            this.btnEmployeeSearch.ImageSize = new System.Drawing.Size(20, 20);
            this.btnEmployeeSearch.LineBottom = 7;
            this.btnEmployeeSearch.LineColor = System.Drawing.Color.White;
            this.btnEmployeeSearch.Location = new System.Drawing.Point(829, 0);
            this.btnEmployeeSearch.Name = "btnEmployeeSearch";
            this.btnEmployeeSearch.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnEmployeeSearch.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnEmployeeSearch.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearch.OnHoverImage = null;
            this.btnEmployeeSearch.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearch.OnPressedColor = System.Drawing.Color.Black;
            this.btnEmployeeSearch.Size = new System.Drawing.Size(277, 70);
            this.btnEmployeeSearch.TabIndex = 3;
            this.btnEmployeeSearch.Text = "Search Book";
            this.btnEmployeeSearch.Click += new System.EventHandler(this.btnEmployeeSearch_Click);
            // 
            // btnEmployeeReturnBook
            // 
            this.btnEmployeeReturnBook.Animated = true;
            this.btnEmployeeReturnBook.AnimationHoverSpeed = 0.8F;
            this.btnEmployeeReturnBook.AnimationSpeed = 0.8F;
            this.btnEmployeeReturnBook.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnEmployeeReturnBook.BaseColor = System.Drawing.Color.White;
            this.btnEmployeeReturnBook.BorderColor = System.Drawing.Color.Black;
            this.btnEmployeeReturnBook.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton;
            this.btnEmployeeReturnBook.CheckedBaseColor = System.Drawing.Color.White;
            this.btnEmployeeReturnBook.CheckedBorderColor = System.Drawing.Color.Black;
            this.btnEmployeeReturnBook.CheckedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeReturnBook.CheckedImage = null;
            this.btnEmployeeReturnBook.CheckedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeReturnBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmployeeReturnBook.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEmployeeReturnBook.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEmployeeReturnBook.FocusedColor = System.Drawing.Color.Empty;
            this.btnEmployeeReturnBook.Font = new System.Drawing.Font("Lucida Sans Unicode", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeReturnBook.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeReturnBook.Image = null;
            this.btnEmployeeReturnBook.ImageSize = new System.Drawing.Size(20, 20);
            this.btnEmployeeReturnBook.LineBottom = 7;
            this.btnEmployeeReturnBook.LineColor = System.Drawing.Color.White;
            this.btnEmployeeReturnBook.Location = new System.Drawing.Point(533, 0);
            this.btnEmployeeReturnBook.Name = "btnEmployeeReturnBook";
            this.btnEmployeeReturnBook.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnEmployeeReturnBook.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnEmployeeReturnBook.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeReturnBook.OnHoverImage = null;
            this.btnEmployeeReturnBook.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeReturnBook.OnPressedColor = System.Drawing.Color.Black;
            this.btnEmployeeReturnBook.Size = new System.Drawing.Size(296, 70);
            this.btnEmployeeReturnBook.TabIndex = 2;
            this.btnEmployeeReturnBook.Text = "Book Return";
            this.btnEmployeeReturnBook.Click += new System.EventHandler(this.btnEmployeeReturnBook_Click);
            // 
            // btnEmployeeRentBook
            // 
            this.btnEmployeeRentBook.Animated = true;
            this.btnEmployeeRentBook.AnimationHoverSpeed = 0.8F;
            this.btnEmployeeRentBook.AnimationSpeed = 0.8F;
            this.btnEmployeeRentBook.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnEmployeeRentBook.BaseColor = System.Drawing.Color.White;
            this.btnEmployeeRentBook.BorderColor = System.Drawing.Color.Black;
            this.btnEmployeeRentBook.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton;
            this.btnEmployeeRentBook.CheckedBaseColor = System.Drawing.Color.White;
            this.btnEmployeeRentBook.CheckedBorderColor = System.Drawing.Color.Black;
            this.btnEmployeeRentBook.CheckedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeRentBook.CheckedImage = null;
            this.btnEmployeeRentBook.CheckedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeRentBook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmployeeRentBook.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEmployeeRentBook.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEmployeeRentBook.FocusedColor = System.Drawing.Color.Empty;
            this.btnEmployeeRentBook.Font = new System.Drawing.Font("Lucida Sans Unicode", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeRentBook.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeRentBook.Image = null;
            this.btnEmployeeRentBook.ImageSize = new System.Drawing.Size(20, 20);
            this.btnEmployeeRentBook.LineBottom = 7;
            this.btnEmployeeRentBook.LineColor = System.Drawing.Color.White;
            this.btnEmployeeRentBook.Location = new System.Drawing.Point(268, 0);
            this.btnEmployeeRentBook.Name = "btnEmployeeRentBook";
            this.btnEmployeeRentBook.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnEmployeeRentBook.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnEmployeeRentBook.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeRentBook.OnHoverImage = null;
            this.btnEmployeeRentBook.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeRentBook.OnPressedColor = System.Drawing.Color.Black;
            this.btnEmployeeRentBook.Size = new System.Drawing.Size(265, 70);
            this.btnEmployeeRentBook.TabIndex = 1;
            this.btnEmployeeRentBook.Text = "Book Rent";
            this.btnEmployeeRentBook.Click += new System.EventHandler(this.btnEmployeeRentBook_Click);
            // 
            // btnEmployeeBooks
            // 
            this.btnEmployeeBooks.Animated = true;
            this.btnEmployeeBooks.AnimationHoverSpeed = 0.8F;
            this.btnEmployeeBooks.AnimationSpeed = 0.8F;
            this.btnEmployeeBooks.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnEmployeeBooks.BaseColor = System.Drawing.Color.White;
            this.btnEmployeeBooks.BorderColor = System.Drawing.Color.Black;
            this.btnEmployeeBooks.ButtonType = Guna.UI.WinForms.AdvenceButtonType.RadioButton;
            this.btnEmployeeBooks.Checked = true;
            this.btnEmployeeBooks.CheckedBaseColor = System.Drawing.Color.White;
            this.btnEmployeeBooks.CheckedBorderColor = System.Drawing.Color.Black;
            this.btnEmployeeBooks.CheckedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeBooks.CheckedImage = null;
            this.btnEmployeeBooks.CheckedLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeBooks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmployeeBooks.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEmployeeBooks.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEmployeeBooks.FocusedColor = System.Drawing.Color.Empty;
            this.btnEmployeeBooks.Font = new System.Drawing.Font("Lucida Sans Unicode", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeBooks.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeBooks.Image = null;
            this.btnEmployeeBooks.ImageSize = new System.Drawing.Size(20, 20);
            this.btnEmployeeBooks.LineBottom = 7;
            this.btnEmployeeBooks.LineColor = System.Drawing.Color.White;
            this.btnEmployeeBooks.Location = new System.Drawing.Point(0, 0);
            this.btnEmployeeBooks.Name = "btnEmployeeBooks";
            this.btnEmployeeBooks.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnEmployeeBooks.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnEmployeeBooks.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeBooks.OnHoverImage = null;
            this.btnEmployeeBooks.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeBooks.OnPressedColor = System.Drawing.Color.Black;
            this.btnEmployeeBooks.Size = new System.Drawing.Size(268, 70);
            this.btnEmployeeBooks.TabIndex = 0;
            this.btnEmployeeBooks.Text = "Books";
            this.btnEmployeeBooks.Click += new System.EventHandler(this.btnEmployeeBooks_Click);
            // 
            // panelEmployeeBody
            // 
            this.panelEmployeeBody.Controls.Add(this.pnlBookReturn);
            this.panelEmployeeBody.Controls.Add(this.pnlSearchBook);
            this.panelEmployeeBody.Controls.Add(this.pnlEmployeeRents);
            this.panelEmployeeBody.Controls.Add(this.pnlEmployeeBooks);
            this.panelEmployeeBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEmployeeBody.Location = new System.Drawing.Point(0, 167);
            this.panelEmployeeBody.Name = "panelEmployeeBody";
            this.panelEmployeeBody.Size = new System.Drawing.Size(1396, 609);
            this.panelEmployeeBody.TabIndex = 2;
            // 
            // pnlBookReturn
            // 
            this.pnlBookReturn.Controls.Add(this.cmbReturnDate);
            this.pnlBookReturn.Controls.Add(this.btnEmployeeReturnBooks);
            this.pnlBookReturn.Controls.Add(this.label12);
            this.pnlBookReturn.Controls.Add(this.label13);
            this.pnlBookReturn.Controls.Add(this.btnReturnList);
            this.pnlBookReturn.Controls.Add(this.cmbEmployeeReturnCustomer);
            this.pnlBookReturn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBookReturn.Location = new System.Drawing.Point(0, 0);
            this.pnlBookReturn.Name = "pnlBookReturn";
            this.pnlBookReturn.Size = new System.Drawing.Size(1396, 609);
            this.pnlBookReturn.TabIndex = 61;
            // 
            // btnEmployeeReturnBooks
            // 
            this.btnEmployeeReturnBooks.AnimationHoverSpeed = 0.7F;
            this.btnEmployeeReturnBooks.AnimationSpeed = 0.7F;
            this.btnEmployeeReturnBooks.BackColor = System.Drawing.Color.Transparent;
            this.btnEmployeeReturnBooks.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeReturnBooks.BorderColor = System.Drawing.Color.Black;
            this.btnEmployeeReturnBooks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmployeeReturnBooks.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEmployeeReturnBooks.FocusedColor = System.Drawing.Color.Empty;
            this.btnEmployeeReturnBooks.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeReturnBooks.ForeColor = System.Drawing.Color.White;
            this.btnEmployeeReturnBooks.Image = null;
            this.btnEmployeeReturnBooks.ImageSize = new System.Drawing.Size(20, 20);
            this.btnEmployeeReturnBooks.Location = new System.Drawing.Point(348, 343);
            this.btnEmployeeReturnBooks.Name = "btnEmployeeReturnBooks";
            this.btnEmployeeReturnBooks.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(35)))), ((int)(((byte)(76)))));
            this.btnEmployeeReturnBooks.OnHoverBorderColor = System.Drawing.Color.White;
            this.btnEmployeeReturnBooks.OnHoverForeColor = System.Drawing.Color.White;
            this.btnEmployeeReturnBooks.OnHoverImage = null;
            this.btnEmployeeReturnBooks.OnPressedColor = System.Drawing.Color.Black;
            this.btnEmployeeReturnBooks.Radius = 25;
            this.btnEmployeeReturnBooks.Size = new System.Drawing.Size(363, 56);
            this.btnEmployeeReturnBooks.TabIndex = 69;
            this.btnEmployeeReturnBooks.Text = "Return Books";
            this.btnEmployeeReturnBooks.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnEmployeeReturnBooks.Click += new System.EventHandler(this.btnEmployeeReturnBooks_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label12.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label12.Location = new System.Drawing.Point(44, 211);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(177, 39);
            this.label12.TabIndex = 64;
            this.label12.Text = "Return Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label13.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label13.Location = new System.Drawing.Point(44, 98);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(213, 39);
            this.label13.TabIndex = 63;
            this.label13.Text = "Member Name:";
            // 
            // btnReturnList
            // 
            this.btnReturnList.CheckOnClick = true;
            this.btnReturnList.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturnList.FormattingEnabled = true;
            this.btnReturnList.Location = new System.Drawing.Point(817, 98);
            this.btnReturnList.Name = "btnReturnList";
            this.btnReturnList.Size = new System.Drawing.Size(500, 301);
            this.btnReturnList.TabIndex = 61;
            // 
            // cmbEmployeeReturnCustomer
            // 
            this.cmbEmployeeReturnCustomer.BackColor = System.Drawing.Color.Transparent;
            this.cmbEmployeeReturnCustomer.BaseColor = System.Drawing.Color.White;
            this.cmbEmployeeReturnCustomer.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeReturnCustomer.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbEmployeeReturnCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmployeeReturnCustomer.FocusedColor = System.Drawing.Color.Empty;
            this.cmbEmployeeReturnCustomer.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEmployeeReturnCustomer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeReturnCustomer.FormattingEnabled = true;
            this.cmbEmployeeReturnCustomer.Location = new System.Drawing.Point(348, 98);
            this.cmbEmployeeReturnCustomer.Name = "cmbEmployeeReturnCustomer";
            this.cmbEmployeeReturnCustomer.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeReturnCustomer.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cmbEmployeeReturnCustomer.Size = new System.Drawing.Size(363, 39);
            this.cmbEmployeeReturnCustomer.TabIndex = 59;
            // 
            // pnlSearchBook
            // 
            this.pnlSearchBook.Controls.Add(this.btnEmployeeSearchBooks);
            this.pnlSearchBook.Controls.Add(this.dgvEmployeeSearchResult);
            this.pnlSearchBook.Controls.Add(this.txtEmployeeSearch);
            this.pnlSearchBook.Controls.Add(this.label2);
            this.pnlSearchBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSearchBook.Location = new System.Drawing.Point(0, 0);
            this.pnlSearchBook.Name = "pnlSearchBook";
            this.pnlSearchBook.Size = new System.Drawing.Size(1396, 609);
            this.pnlSearchBook.TabIndex = 59;
            // 
            // btnEmployeeSearchBooks
            // 
            this.btnEmployeeSearchBooks.AnimationHoverSpeed = 0.07F;
            this.btnEmployeeSearchBooks.AnimationSpeed = 0.03F;
            this.btnEmployeeSearchBooks.BackColor = System.Drawing.Color.Transparent;
            this.btnEmployeeSearchBooks.BaseColor = System.Drawing.SystemColors.Control;
            this.btnEmployeeSearchBooks.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearchBooks.BorderSize = 3;
            this.btnEmployeeSearchBooks.CheckedBaseColor = System.Drawing.SystemColors.Control;
            this.btnEmployeeSearchBooks.CheckedBorderColor = System.Drawing.Color.Transparent;
            this.btnEmployeeSearchBooks.CheckedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearchBooks.CheckedImage = null;
            this.btnEmployeeSearchBooks.CheckedLineColor = System.Drawing.Color.DimGray;
            this.btnEmployeeSearchBooks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmployeeSearchBooks.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEmployeeSearchBooks.FocusedColor = System.Drawing.Color.Empty;
            this.btnEmployeeSearchBooks.Font = new System.Drawing.Font("Comic Sans MS", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeSearchBooks.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearchBooks.Image = null;
            this.btnEmployeeSearchBooks.ImageSize = new System.Drawing.Size(20, 20);
            this.btnEmployeeSearchBooks.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.btnEmployeeSearchBooks.Location = new System.Drawing.Point(398, 291);
            this.btnEmployeeSearchBooks.Name = "btnEmployeeSearchBooks";
            this.btnEmployeeSearchBooks.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeSearchBooks.OnHoverBorderColor = System.Drawing.Color.Transparent;
            this.btnEmployeeSearchBooks.OnHoverForeColor = System.Drawing.Color.White;
            this.btnEmployeeSearchBooks.OnHoverImage = null;
            this.btnEmployeeSearchBooks.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.btnEmployeeSearchBooks.OnPressedColor = System.Drawing.Color.Black;
            this.btnEmployeeSearchBooks.Radius = 25;
            this.btnEmployeeSearchBooks.Size = new System.Drawing.Size(556, 77);
            this.btnEmployeeSearchBooks.TabIndex = 3;
            this.btnEmployeeSearchBooks.Text = "Search";
            this.btnEmployeeSearchBooks.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnEmployeeSearchBooks.Click += new System.EventHandler(this.btnEmployeeSearchBooks_Click);
            // 
            // dgvEmployeeSearchResult
            // 
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            this.dgvEmployeeSearchResult.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvEmployeeSearchResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEmployeeSearchResult.BackgroundColor = System.Drawing.Color.White;
            this.dgvEmployeeSearchResult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvEmployeeSearchResult.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvEmployeeSearchResult.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmployeeSearchResult.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvEmployeeSearchResult.ColumnHeadersHeight = 40;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEmployeeSearchResult.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgvEmployeeSearchResult.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvEmployeeSearchResult.EnableHeadersVisualStyles = false;
            this.dgvEmployeeSearchResult.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvEmployeeSearchResult.Location = new System.Drawing.Point(0, 405);
            this.dgvEmployeeSearchResult.Name = "dgvEmployeeSearchResult";
            this.dgvEmployeeSearchResult.RowHeadersVisible = false;
            this.dgvEmployeeSearchResult.RowHeadersWidth = 51;
            this.dgvEmployeeSearchResult.RowTemplate.Height = 24;
            this.dgvEmployeeSearchResult.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmployeeSearchResult.Size = new System.Drawing.Size(1396, 204);
            this.dgvEmployeeSearchResult.TabIndex = 2;
            this.dgvEmployeeSearchResult.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.dgvEmployeeSearchResult.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvEmployeeSearchResult.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvEmployeeSearchResult.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvEmployeeSearchResult.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvEmployeeSearchResult.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvEmployeeSearchResult.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvEmployeeSearchResult.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvEmployeeSearchResult.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvEmployeeSearchResult.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvEmployeeSearchResult.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dgvEmployeeSearchResult.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvEmployeeSearchResult.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvEmployeeSearchResult.ThemeStyle.HeaderStyle.Height = 40;
            this.dgvEmployeeSearchResult.ThemeStyle.ReadOnly = false;
            this.dgvEmployeeSearchResult.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvEmployeeSearchResult.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvEmployeeSearchResult.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dgvEmployeeSearchResult.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.dgvEmployeeSearchResult.ThemeStyle.RowsStyle.Height = 24;
            this.dgvEmployeeSearchResult.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvEmployeeSearchResult.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // txtEmployeeSearch
            // 
            this.txtEmployeeSearch.AcceptsReturn = false;
            this.txtEmployeeSearch.AcceptsTab = false;
            this.txtEmployeeSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmployeeSearch.AnimationSpeed = 200;
            this.txtEmployeeSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtEmployeeSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtEmployeeSearch.BackColor = System.Drawing.SystemColors.Control;
            this.txtEmployeeSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtEmployeeSearch.BackgroundImage")));
            this.txtEmployeeSearch.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtEmployeeSearch.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtEmployeeSearch.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtEmployeeSearch.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtEmployeeSearch.BorderRadius = 1;
            this.txtEmployeeSearch.BorderThickness = 5;
            this.txtEmployeeSearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtEmployeeSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmployeeSearch.DefaultFont = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmployeeSearch.DefaultText = "";
            this.txtEmployeeSearch.FillColor = System.Drawing.SystemColors.Control;
            this.txtEmployeeSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtEmployeeSearch.HideSelection = true;
            this.txtEmployeeSearch.IconLeft = null;
            this.txtEmployeeSearch.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmployeeSearch.IconPadding = 0;
            this.txtEmployeeSearch.IconRight = null;
            this.txtEmployeeSearch.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmployeeSearch.Lines = new string[0];
            this.txtEmployeeSearch.Location = new System.Drawing.Point(310, 121);
            this.txtEmployeeSearch.MaxLength = 32767;
            this.txtEmployeeSearch.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtEmployeeSearch.Modified = false;
            this.txtEmployeeSearch.Multiline = false;
            this.txtEmployeeSearch.Name = "txtEmployeeSearch";
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEmployeeSearch.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtEmployeeSearch.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEmployeeSearch.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.SystemColors.Control;
            stateProperties8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtEmployeeSearch.OnIdleState = stateProperties8;
            this.txtEmployeeSearch.PasswordChar = '\0';
            this.txtEmployeeSearch.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtEmployeeSearch.PlaceholderText = "Enter book name here";
            this.txtEmployeeSearch.ReadOnly = false;
            this.txtEmployeeSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtEmployeeSearch.SelectedText = "";
            this.txtEmployeeSearch.SelectionLength = 0;
            this.txtEmployeeSearch.SelectionStart = 0;
            this.txtEmployeeSearch.ShortcutsEnabled = true;
            this.txtEmployeeSearch.Size = new System.Drawing.Size(735, 78);
            this.txtEmployeeSearch.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtEmployeeSearch.TabIndex = 1;
            this.txtEmployeeSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtEmployeeSearch.TextMarginBottom = 0;
            this.txtEmployeeSearch.TextMarginLeft = 5;
            this.txtEmployeeSearch.TextMarginTop = 0;
            this.txtEmployeeSearch.TextPlaceholder = "Enter book name here";
            this.txtEmployeeSearch.UseSystemPasswordChar = false;
            this.txtEmployeeSearch.WordWrap = true;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label2.Location = new System.Drawing.Point(303, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(709, 40);
            this.label2.TabIndex = 0;
            this.label2.Text = "Enter the book name you are looking for:";
            // 
            // pnlEmployeeRents
            // 
            this.pnlEmployeeRents.Controls.Add(this.cmbReturnDay);
            this.pnlEmployeeRents.Controls.Add(this.cmbReturnMonth);
            this.pnlEmployeeRents.Controls.Add(this.cmbReturnYear);
            this.pnlEmployeeRents.Controls.Add(this.label5);
            this.pnlEmployeeRents.Controls.Add(this.label6);
            this.pnlEmployeeRents.Controls.Add(this.label11);
            this.pnlEmployeeRents.Controls.Add(this.AddBooks);
            this.pnlEmployeeRents.Controls.Add(this.numBook);
            this.pnlEmployeeRents.Controls.Add(this.label7);
            this.pnlEmployeeRents.Controls.Add(this.btnEmployeeRentConfirm);
            this.pnlEmployeeRents.Controls.Add(this.label1);
            this.pnlEmployeeRents.Controls.Add(this.label4);
            this.pnlEmployeeRents.Controls.Add(this.label3);
            this.pnlEmployeeRents.Controls.Add(this.lstAddedBooks);
            this.pnlEmployeeRents.Controls.Add(this.cmbEmployeeCustomerNames);
            this.pnlEmployeeRents.Controls.Add(this.cmbEmployeeRentBook);
            this.pnlEmployeeRents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlEmployeeRents.Location = new System.Drawing.Point(0, 0);
            this.pnlEmployeeRents.Name = "pnlEmployeeRents";
            this.pnlEmployeeRents.Size = new System.Drawing.Size(1396, 609);
            this.pnlEmployeeRents.TabIndex = 1;
            // 
            // AddBooks
            // 
            this.AddBooks.AnimationHoverSpeed = 0.7F;
            this.AddBooks.AnimationSpeed = 0.7F;
            this.AddBooks.BackColor = System.Drawing.Color.Transparent;
            this.AddBooks.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.AddBooks.BorderColor = System.Drawing.Color.Black;
            this.AddBooks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddBooks.DialogResult = System.Windows.Forms.DialogResult.None;
            this.AddBooks.FocusedColor = System.Drawing.Color.Empty;
            this.AddBooks.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddBooks.ForeColor = System.Drawing.Color.White;
            this.AddBooks.Image = null;
            this.AddBooks.ImageSize = new System.Drawing.Size(20, 20);
            this.AddBooks.Location = new System.Drawing.Point(365, 270);
            this.AddBooks.Name = "AddBooks";
            this.AddBooks.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(35)))), ((int)(((byte)(76)))));
            this.AddBooks.OnHoverBorderColor = System.Drawing.Color.White;
            this.AddBooks.OnHoverForeColor = System.Drawing.Color.White;
            this.AddBooks.OnHoverImage = null;
            this.AddBooks.OnPressedColor = System.Drawing.Color.Black;
            this.AddBooks.Radius = 25;
            this.AddBooks.Size = new System.Drawing.Size(363, 60);
            this.AddBooks.TabIndex = 57;
            this.AddBooks.Text = "Add To List";
            this.AddBooks.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AddBooks.Click += new System.EventHandler(this.AddBooks_Click);
            // 
            // numBook
            // 
            this.numBook.BaseColor = System.Drawing.Color.White;
            this.numBook.BorderColor = System.Drawing.Color.Silver;
            this.numBook.ButtonColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.numBook.ButtonForeColor = System.Drawing.Color.White;
            this.numBook.Font = new System.Drawing.Font("Lucida Sans Unicode", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numBook.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.numBook.Location = new System.Drawing.Point(365, 187);
            this.numBook.Maximum = ((long)(9999999));
            this.numBook.Minimum = ((long)(0));
            this.numBook.Name = "numBook";
            this.numBook.Size = new System.Drawing.Size(363, 30);
            this.numBook.TabIndex = 56;
            this.numBook.Text = "gunaNumeric1";
            this.numBook.Value = ((long)(0));
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label7.Location = new System.Drawing.Point(44, 178);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(213, 39);
            this.label7.TabIndex = 55;
            this.label7.Text = "Book Quantity:";
            // 
            // btnEmployeeRentConfirm
            // 
            this.btnEmployeeRentConfirm.AnimationHoverSpeed = 0.7F;
            this.btnEmployeeRentConfirm.AnimationSpeed = 0.7F;
            this.btnEmployeeRentConfirm.BackColor = System.Drawing.Color.Transparent;
            this.btnEmployeeRentConfirm.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnEmployeeRentConfirm.BorderColor = System.Drawing.Color.Black;
            this.btnEmployeeRentConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEmployeeRentConfirm.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnEmployeeRentConfirm.FocusedColor = System.Drawing.Color.Empty;
            this.btnEmployeeRentConfirm.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmployeeRentConfirm.ForeColor = System.Drawing.Color.White;
            this.btnEmployeeRentConfirm.Image = null;
            this.btnEmployeeRentConfirm.ImageSize = new System.Drawing.Size(20, 20);
            this.btnEmployeeRentConfirm.Location = new System.Drawing.Point(852, 463);
            this.btnEmployeeRentConfirm.Name = "btnEmployeeRentConfirm";
            this.btnEmployeeRentConfirm.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(35)))), ((int)(((byte)(76)))));
            this.btnEmployeeRentConfirm.OnHoverBorderColor = System.Drawing.Color.White;
            this.btnEmployeeRentConfirm.OnHoverForeColor = System.Drawing.Color.White;
            this.btnEmployeeRentConfirm.OnHoverImage = null;
            this.btnEmployeeRentConfirm.OnPressedColor = System.Drawing.Color.Black;
            this.btnEmployeeRentConfirm.Radius = 25;
            this.btnEmployeeRentConfirm.Size = new System.Drawing.Size(500, 68);
            this.btnEmployeeRentConfirm.TabIndex = 54;
            this.btnEmployeeRentConfirm.Text = "Rent";
            this.btnEmployeeRentConfirm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnEmployeeRentConfirm.Click += new System.EventHandler(this.btnEmployeeRentConfirm_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label1.Location = new System.Drawing.Point(44, 380);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(508, 39);
            this.label1.TabIndex = 49;
            this.label1.Text = "Choose Date books must be returned:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label4.Location = new System.Drawing.Point(44, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 39);
            this.label4.TabIndex = 48;
            this.label4.Text = "Book Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label3.Location = new System.Drawing.Point(44, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(213, 39);
            this.label3.TabIndex = 47;
            this.label3.Text = "Member Name:";
            // 
            // lstAddedBooks
            // 
            this.lstAddedBooks.CheckOnClick = true;
            this.lstAddedBooks.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstAddedBooks.FormattingEnabled = true;
            this.lstAddedBooks.Location = new System.Drawing.Point(852, 29);
            this.lstAddedBooks.Name = "lstAddedBooks";
            this.lstAddedBooks.Size = new System.Drawing.Size(500, 301);
            this.lstAddedBooks.TabIndex = 3;
            // 
            // cmbEmployeeCustomerNames
            // 
            this.cmbEmployeeCustomerNames.BackColor = System.Drawing.Color.Transparent;
            this.cmbEmployeeCustomerNames.BaseColor = System.Drawing.Color.White;
            this.cmbEmployeeCustomerNames.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeCustomerNames.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbEmployeeCustomerNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmployeeCustomerNames.FocusedColor = System.Drawing.Color.Empty;
            this.cmbEmployeeCustomerNames.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEmployeeCustomerNames.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeCustomerNames.FormattingEnabled = true;
            this.cmbEmployeeCustomerNames.Location = new System.Drawing.Point(365, 29);
            this.cmbEmployeeCustomerNames.Name = "cmbEmployeeCustomerNames";
            this.cmbEmployeeCustomerNames.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeCustomerNames.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cmbEmployeeCustomerNames.Size = new System.Drawing.Size(363, 39);
            this.cmbEmployeeCustomerNames.TabIndex = 1;
            // 
            // cmbEmployeeRentBook
            // 
            this.cmbEmployeeRentBook.BackColor = System.Drawing.Color.Transparent;
            this.cmbEmployeeRentBook.BaseColor = System.Drawing.Color.White;
            this.cmbEmployeeRentBook.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeRentBook.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbEmployeeRentBook.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmployeeRentBook.FocusedColor = System.Drawing.Color.Empty;
            this.cmbEmployeeRentBook.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEmployeeRentBook.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeRentBook.FormattingEnabled = true;
            this.cmbEmployeeRentBook.Location = new System.Drawing.Point(365, 110);
            this.cmbEmployeeRentBook.Name = "cmbEmployeeRentBook";
            this.cmbEmployeeRentBook.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbEmployeeRentBook.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cmbEmployeeRentBook.Size = new System.Drawing.Size(363, 39);
            this.cmbEmployeeRentBook.TabIndex = 0;
            // 
            // pnlEmployeeBooks
            // 
            this.pnlEmployeeBooks.Controls.Add(this.dgvEmployeeBooks);
            this.pnlEmployeeBooks.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlEmployeeBooks.Location = new System.Drawing.Point(0, 0);
            this.pnlEmployeeBooks.Name = "pnlEmployeeBooks";
            this.pnlEmployeeBooks.Size = new System.Drawing.Size(1396, 609);
            this.pnlEmployeeBooks.TabIndex = 0;
            // 
            // dgvEmployeeBooks
            // 
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            this.dgvEmployeeBooks.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvEmployeeBooks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEmployeeBooks.BackgroundColor = System.Drawing.Color.White;
            this.dgvEmployeeBooks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvEmployeeBooks.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvEmployeeBooks.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmployeeBooks.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvEmployeeBooks.ColumnHeadersHeight = 40;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEmployeeBooks.DefaultCellStyle = dataGridViewCellStyle12;
            this.dgvEmployeeBooks.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEmployeeBooks.EnableHeadersVisualStyles = false;
            this.dgvEmployeeBooks.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvEmployeeBooks.Location = new System.Drawing.Point(0, 0);
            this.dgvEmployeeBooks.Name = "dgvEmployeeBooks";
            this.dgvEmployeeBooks.RowHeadersVisible = false;
            this.dgvEmployeeBooks.RowHeadersWidth = 51;
            this.dgvEmployeeBooks.RowTemplate.Height = 30;
            this.dgvEmployeeBooks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmployeeBooks.Size = new System.Drawing.Size(1396, 609);
            this.dgvEmployeeBooks.TabIndex = 1;
            this.dgvEmployeeBooks.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.dgvEmployeeBooks.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvEmployeeBooks.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvEmployeeBooks.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvEmployeeBooks.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvEmployeeBooks.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvEmployeeBooks.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.dgvEmployeeBooks.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.dgvEmployeeBooks.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.dgvEmployeeBooks.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvEmployeeBooks.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dgvEmployeeBooks.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvEmployeeBooks.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvEmployeeBooks.ThemeStyle.HeaderStyle.Height = 40;
            this.dgvEmployeeBooks.ThemeStyle.ReadOnly = false;
            this.dgvEmployeeBooks.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvEmployeeBooks.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvEmployeeBooks.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvEmployeeBooks.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.dgvEmployeeBooks.ThemeStyle.RowsStyle.Height = 30;
            this.dgvEmployeeBooks.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.dgvEmployeeBooks.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            // 
            // cmbReturnDay
            // 
            this.cmbReturnDay.BackColor = System.Drawing.Color.Transparent;
            this.cmbReturnDay.BaseColor = System.Drawing.Color.White;
            this.cmbReturnDay.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnDay.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbReturnDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReturnDay.FocusedColor = System.Drawing.Color.Empty;
            this.cmbReturnDay.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReturnDay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnDay.FormattingEnabled = true;
            this.cmbReturnDay.Location = new System.Drawing.Point(635, 492);
            this.cmbReturnDay.Name = "cmbReturnDay";
            this.cmbReturnDay.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnDay.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cmbReturnDay.Size = new System.Drawing.Size(93, 39);
            this.cmbReturnDay.TabIndex = 81;
            // 
            // cmbReturnMonth
            // 
            this.cmbReturnMonth.BackColor = System.Drawing.Color.Transparent;
            this.cmbReturnMonth.BaseColor = System.Drawing.Color.White;
            this.cmbReturnMonth.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnMonth.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbReturnMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReturnMonth.FocusedColor = System.Drawing.Color.Empty;
            this.cmbReturnMonth.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReturnMonth.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnMonth.FormattingEnabled = true;
            this.cmbReturnMonth.Location = new System.Drawing.Point(289, 490);
            this.cmbReturnMonth.Name = "cmbReturnMonth";
            this.cmbReturnMonth.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnMonth.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cmbReturnMonth.Size = new System.Drawing.Size(245, 39);
            this.cmbReturnMonth.TabIndex = 80;
            this.cmbReturnMonth.SelectedIndexChanged += new System.EventHandler(this.cmbReturnMonth_SelectedIndexChanged);
            // 
            // cmbReturnYear
            // 
            this.cmbReturnYear.BackColor = System.Drawing.Color.Transparent;
            this.cmbReturnYear.BaseColor = System.Drawing.Color.White;
            this.cmbReturnYear.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnYear.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbReturnYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReturnYear.FocusedColor = System.Drawing.Color.Empty;
            this.cmbReturnYear.Font = new System.Drawing.Font("Lucida Sans Unicode", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReturnYear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnYear.FormattingEnabled = true;
            this.cmbReturnYear.Location = new System.Drawing.Point(51, 492);
            this.cmbReturnYear.Name = "cmbReturnYear";
            this.cmbReturnYear.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnYear.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cmbReturnYear.Size = new System.Drawing.Size(136, 35);
            this.cmbReturnYear.TabIndex = 79;
            this.cmbReturnYear.SelectedIndexChanged += new System.EventHandler(this.cmbReturnYear_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label5.Location = new System.Drawing.Point(629, 447);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 33);
            this.label5.TabIndex = 78;
            this.label5.Text = "Day";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label6.Location = new System.Drawing.Point(283, 447);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 33);
            this.label6.TabIndex = 77;
            this.label6.Text = "Month";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label11.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label11.Location = new System.Drawing.Point(45, 438);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 33);
            this.label11.TabIndex = 76;
            this.label11.Text = "Year";
            // 
            // cmbReturnDate
            // 
            this.cmbReturnDate.BackColor = System.Drawing.Color.Transparent;
            this.cmbReturnDate.BaseColor = System.Drawing.Color.White;
            this.cmbReturnDate.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnDate.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbReturnDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReturnDate.FocusedColor = System.Drawing.Color.Empty;
            this.cmbReturnDate.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReturnDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnDate.FormattingEnabled = true;
            this.cmbReturnDate.Location = new System.Drawing.Point(348, 211);
            this.cmbReturnDate.Name = "cmbReturnDate";
            this.cmbReturnDate.OnHoverItemBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.cmbReturnDate.OnHoverItemForeColor = System.Drawing.Color.White;
            this.cmbReturnDate.Size = new System.Drawing.Size(363, 39);
            this.cmbReturnDate.TabIndex = 70;
            // 
            // LibEmployees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1396, 776);
            this.Controls.Add(this.panelEmployeeBody);
            this.Controls.Add(this.panelEmployeeMenu);
            this.Controls.Add(this.panelEmployeesTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LibEmployees";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LibEmployees";
            this.Load += new System.EventHandler(this.LibEmployees_Load);
            this.panelEmployeesTop.ResumeLayout(false);
            this.panelEmployeesTop.PerformLayout();
            this.panelEmployeeMenu.ResumeLayout(false);
            this.panelEmployeeBody.ResumeLayout(false);
            this.pnlBookReturn.ResumeLayout(false);
            this.pnlBookReturn.PerformLayout();
            this.pnlSearchBook.ResumeLayout(false);
            this.pnlSearchBook.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeeSearchResult)).EndInit();
            this.pnlEmployeeRents.ResumeLayout(false);
            this.pnlEmployeeRents.PerformLayout();
            this.pnlEmployeeBooks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeeBooks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelEmployeesTop;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label minimizeEmployeePage;
        private System.Windows.Forms.Label closeEmployeePage;
        private System.Windows.Forms.Panel panelEmployeeMenu;
        private Guna.UI.WinForms.GunaAdvenceButton btnEmployeeSearch;
        private Guna.UI.WinForms.GunaAdvenceButton btnEmployeeReturnBook;
        private Guna.UI.WinForms.GunaAdvenceButton btnEmployeeRentBook;
        private Guna.UI.WinForms.GunaAdvenceButton btnEmployeeBooks;
        private System.Windows.Forms.Panel panelEmployeeBody;
        private System.Windows.Forms.Panel pnlEmployeeRents;
        private System.Windows.Forms.Panel pnlEmployeeBooks;
        private Guna.UI.WinForms.GunaDataGridView dgvEmployeeBooks;
        private Guna.UI.WinForms.GunaComboBox cmbEmployeeRentBook;
        private Guna.UI.WinForms.GunaComboBox cmbEmployeeCustomerNames;
        private System.Windows.Forms.CheckedListBox lstAddedBooks;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Guna.UI.WinForms.GunaButton btnEmployeeRentConfirm;
        private Guna.UI.WinForms.GunaNumeric numBook;
        private System.Windows.Forms.Label label7;
        private Guna.UI.WinForms.GunaButton AddBooks;
        private System.Windows.Forms.Panel pnlSearchBook;
        private Guna.UI.WinForms.GunaAdvenceButton btnEmployeeSearchBooks;
        private Guna.UI.WinForms.GunaDataGridView dgvEmployeeSearchResult;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtEmployeeSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlBookReturn;
        private Guna.UI.WinForms.GunaButton btnEmployeeReturnBooks;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckedListBox btnReturnList;
        private Guna.UI.WinForms.GunaComboBox cmbEmployeeReturnCustomer;
        private Guna.UI.WinForms.GunaComboBox cmbReturnDay;
        private Guna.UI.WinForms.GunaComboBox cmbReturnMonth;
        private Guna.UI.WinForms.GunaComboBox cmbReturnYear;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private Guna.UI.WinForms.GunaComboBox cmbReturnDate;
    }
}