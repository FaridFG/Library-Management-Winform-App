﻿namespace LibraryManagement
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUp));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.panelSignUpLeft = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelSignUpRight = new System.Windows.Forms.Panel();
            this.minimizeSignUp = new System.Windows.Forms.Label();
            this.closeSignUp = new System.Windows.Forms.Label();
            this.btnSignUpCancel = new Guna.UI.WinForms.GunaButton();
            this.btnSignUp = new Guna.UI.WinForms.GunaButton();
            this.label10 = new System.Windows.Forms.Label();
            this.chbAgreeTerms = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.chbSignUpShowPassword = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.txtSignUpPasswordConfirm = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSingUpPassword = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSignUpUsername = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSignUpEmail = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSignUpSurname = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSignUpName = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelSignUpLeft.SuspendLayout();
            this.panelSignUpRight.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSignUpLeft
            // 
            this.panelSignUpLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.panelSignUpLeft.Controls.Add(this.label1);
            this.panelSignUpLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSignUpLeft.Location = new System.Drawing.Point(0, 0);
            this.panelSignUpLeft.Name = "panelSignUpLeft";
            this.panelSignUpLeft.Size = new System.Drawing.Size(379, 771);
            this.panelSignUpLeft.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(348, 420);
            this.label1.TabIndex = 0;
            this.label1.Text = "  Reading\r\n     is\r\n Dreaming\r\nWith Open\r\n    Eyes";
            // 
            // panelSignUpRight
            // 
            this.panelSignUpRight.Controls.Add(this.minimizeSignUp);
            this.panelSignUpRight.Controls.Add(this.closeSignUp);
            this.panelSignUpRight.Controls.Add(this.btnSignUpCancel);
            this.panelSignUpRight.Controls.Add(this.btnSignUp);
            this.panelSignUpRight.Controls.Add(this.label10);
            this.panelSignUpRight.Controls.Add(this.chbAgreeTerms);
            this.panelSignUpRight.Controls.Add(this.label9);
            this.panelSignUpRight.Controls.Add(this.chbSignUpShowPassword);
            this.panelSignUpRight.Controls.Add(this.txtSignUpPasswordConfirm);
            this.panelSignUpRight.Controls.Add(this.label7);
            this.panelSignUpRight.Controls.Add(this.txtSingUpPassword);
            this.panelSignUpRight.Controls.Add(this.label6);
            this.panelSignUpRight.Controls.Add(this.txtSignUpUsername);
            this.panelSignUpRight.Controls.Add(this.label8);
            this.panelSignUpRight.Controls.Add(this.txtSignUpEmail);
            this.panelSignUpRight.Controls.Add(this.label5);
            this.panelSignUpRight.Controls.Add(this.txtSignUpSurname);
            this.panelSignUpRight.Controls.Add(this.label4);
            this.panelSignUpRight.Controls.Add(this.txtSignUpName);
            this.panelSignUpRight.Controls.Add(this.label3);
            this.panelSignUpRight.Controls.Add(this.label2);
            this.panelSignUpRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSignUpRight.Location = new System.Drawing.Point(379, 0);
            this.panelSignUpRight.Name = "panelSignUpRight";
            this.panelSignUpRight.Size = new System.Drawing.Size(965, 771);
            this.panelSignUpRight.TabIndex = 1;
            // 
            // minimizeSignUp
            // 
            this.minimizeSignUp.AutoSize = true;
            this.minimizeSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimizeSignUp.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimizeSignUp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.minimizeSignUp.Location = new System.Drawing.Point(824, 1);
            this.minimizeSignUp.Name = "minimizeSignUp";
            this.minimizeSignUp.Size = new System.Drawing.Size(59, 67);
            this.minimizeSignUp.TabIndex = 38;
            this.minimizeSignUp.Text = "_";
            this.minimizeSignUp.Click += new System.EventHandler(this.minimizeSignUp_Click);
            // 
            // closeSignUp
            // 
            this.closeSignUp.AutoSize = true;
            this.closeSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeSignUp.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeSignUp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.closeSignUp.Location = new System.Drawing.Point(889, 9);
            this.closeSignUp.Name = "closeSignUp";
            this.closeSignUp.Size = new System.Drawing.Size(64, 67);
            this.closeSignUp.TabIndex = 37;
            this.closeSignUp.Text = "X";
            this.closeSignUp.Click += new System.EventHandler(this.closeSignUp_Click);
            // 
            // btnSignUpCancel
            // 
            this.btnSignUpCancel.AnimationHoverSpeed = 0.7F;
            this.btnSignUpCancel.AnimationSpeed = 0.7F;
            this.btnSignUpCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnSignUpCancel.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnSignUpCancel.BorderColor = System.Drawing.Color.Black;
            this.btnSignUpCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignUpCancel.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSignUpCancel.FocusedColor = System.Drawing.Color.Empty;
            this.btnSignUpCancel.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignUpCancel.ForeColor = System.Drawing.Color.White;
            this.btnSignUpCancel.Image = null;
            this.btnSignUpCancel.ImageSize = new System.Drawing.Size(20, 20);
            this.btnSignUpCancel.Location = new System.Drawing.Point(513, 654);
            this.btnSignUpCancel.Name = "btnSignUpCancel";
            this.btnSignUpCancel.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(35)))), ((int)(((byte)(76)))));
            this.btnSignUpCancel.OnHoverBorderColor = System.Drawing.Color.White;
            this.btnSignUpCancel.OnHoverForeColor = System.Drawing.Color.White;
            this.btnSignUpCancel.OnHoverImage = null;
            this.btnSignUpCancel.OnPressedColor = System.Drawing.Color.Black;
            this.btnSignUpCancel.Radius = 30;
            this.btnSignUpCancel.Size = new System.Drawing.Size(403, 76);
            this.btnSignUpCancel.TabIndex = 36;
            this.btnSignUpCancel.Text = "Cancel";
            this.btnSignUpCancel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSignUpCancel.Click += new System.EventHandler(this.btnSignUpCancel_Click);
            // 
            // btnSignUp
            // 
            this.btnSignUp.AnimationHoverSpeed = 0.7F;
            this.btnSignUp.AnimationSpeed = 0.7F;
            this.btnSignUp.BackColor = System.Drawing.Color.Transparent;
            this.btnSignUp.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnSignUp.BorderColor = System.Drawing.Color.Black;
            this.btnSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignUp.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSignUp.FocusedColor = System.Drawing.Color.Empty;
            this.btnSignUp.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignUp.ForeColor = System.Drawing.Color.White;
            this.btnSignUp.Image = null;
            this.btnSignUp.ImageSize = new System.Drawing.Size(20, 20);
            this.btnSignUp.Location = new System.Drawing.Point(43, 654);
            this.btnSignUp.Name = "btnSignUp";
            this.btnSignUp.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(35)))), ((int)(((byte)(76)))));
            this.btnSignUp.OnHoverBorderColor = System.Drawing.Color.White;
            this.btnSignUp.OnHoverForeColor = System.Drawing.Color.White;
            this.btnSignUp.OnHoverImage = null;
            this.btnSignUp.OnPressedColor = System.Drawing.Color.Black;
            this.btnSignUp.Radius = 30;
            this.btnSignUp.Size = new System.Drawing.Size(403, 76);
            this.btnSignUp.TabIndex = 35;
            this.btnSignUp.Text = "Sign Up";
            this.btnSignUp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSignUp.Click += new System.EventHandler(this.btnSignUp_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label10.Location = new System.Drawing.Point(83, 582);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(510, 33);
            this.label10.TabIndex = 34;
            this.label10.Text = "Agree to Our Terms and Conditions";
            // 
            // chbAgreeTerms
            // 
            this.chbAgreeTerms.AllowBindingControlAnimation = true;
            this.chbAgreeTerms.AllowBindingControlColorChanges = false;
            this.chbAgreeTerms.AllowBindingControlLocation = true;
            this.chbAgreeTerms.AllowCheckBoxAnimation = true;
            this.chbAgreeTerms.AllowCheckmarkAnimation = true;
            this.chbAgreeTerms.AllowOnHoverStates = true;
            this.chbAgreeTerms.AutoCheck = true;
            this.chbAgreeTerms.BackColor = System.Drawing.Color.Transparent;
            this.chbAgreeTerms.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chbAgreeTerms.BackgroundImage")));
            this.chbAgreeTerms.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chbAgreeTerms.BindingControl = null;
            this.chbAgreeTerms.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chbAgreeTerms.Checked = false;
            this.chbAgreeTerms.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Unchecked;
            this.chbAgreeTerms.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chbAgreeTerms.CustomCheckmarkImage = null;
            this.chbAgreeTerms.Location = new System.Drawing.Point(42, 582);
            this.chbAgreeTerms.MinimumSize = new System.Drawing.Size(17, 17);
            this.chbAgreeTerms.Name = "chbAgreeTerms";
            this.chbAgreeTerms.OnCheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbAgreeTerms.OnCheck.BorderRadius = 2;
            this.chbAgreeTerms.OnCheck.BorderThickness = 2;
            this.chbAgreeTerms.OnCheck.CheckBoxColor = System.Drawing.Color.White;
            this.chbAgreeTerms.OnCheck.CheckmarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbAgreeTerms.OnCheck.CheckmarkThickness = 5;
            this.chbAgreeTerms.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chbAgreeTerms.OnDisable.BorderRadius = 2;
            this.chbAgreeTerms.OnDisable.BorderThickness = 2;
            this.chbAgreeTerms.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chbAgreeTerms.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chbAgreeTerms.OnDisable.CheckmarkThickness = 2;
            this.chbAgreeTerms.OnHoverChecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbAgreeTerms.OnHoverChecked.BorderRadius = 2;
            this.chbAgreeTerms.OnHoverChecked.BorderThickness = 2;
            this.chbAgreeTerms.OnHoverChecked.CheckBoxColor = System.Drawing.Color.White;
            this.chbAgreeTerms.OnHoverChecked.CheckmarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbAgreeTerms.OnHoverChecked.CheckmarkThickness = 5;
            this.chbAgreeTerms.OnHoverUnchecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbAgreeTerms.OnHoverUnchecked.BorderRadius = 2;
            this.chbAgreeTerms.OnHoverUnchecked.BorderThickness = 2;
            this.chbAgreeTerms.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.White;
            this.chbAgreeTerms.OnUncheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbAgreeTerms.OnUncheck.BorderRadius = 2;
            this.chbAgreeTerms.OnUncheck.BorderThickness = 2;
            this.chbAgreeTerms.OnUncheck.CheckBoxColor = System.Drawing.Color.White;
            this.chbAgreeTerms.Size = new System.Drawing.Size(35, 35);
            this.chbAgreeTerms.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chbAgreeTerms.TabIndex = 33;
            this.chbAgreeTerms.ThreeState = false;
            this.chbAgreeTerms.ToolTipText = null;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label9.Location = new System.Drawing.Point(83, 509);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(315, 33);
            this.label9.TabIndex = 32;
            this.label9.Text = "Show / Hide Password";
            // 
            // chbSignUpShowPassword
            // 
            this.chbSignUpShowPassword.AllowBindingControlAnimation = true;
            this.chbSignUpShowPassword.AllowBindingControlColorChanges = false;
            this.chbSignUpShowPassword.AllowBindingControlLocation = true;
            this.chbSignUpShowPassword.AllowCheckBoxAnimation = true;
            this.chbSignUpShowPassword.AllowCheckmarkAnimation = true;
            this.chbSignUpShowPassword.AllowOnHoverStates = true;
            this.chbSignUpShowPassword.AutoCheck = true;
            this.chbSignUpShowPassword.BackColor = System.Drawing.Color.Transparent;
            this.chbSignUpShowPassword.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chbSignUpShowPassword.BackgroundImage")));
            this.chbSignUpShowPassword.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chbSignUpShowPassword.BindingControl = null;
            this.chbSignUpShowPassword.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chbSignUpShowPassword.Checked = false;
            this.chbSignUpShowPassword.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Unchecked;
            this.chbSignUpShowPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chbSignUpShowPassword.CustomCheckmarkImage = null;
            this.chbSignUpShowPassword.Location = new System.Drawing.Point(42, 507);
            this.chbSignUpShowPassword.MinimumSize = new System.Drawing.Size(17, 17);
            this.chbSignUpShowPassword.Name = "chbSignUpShowPassword";
            this.chbSignUpShowPassword.OnCheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbSignUpShowPassword.OnCheck.BorderRadius = 2;
            this.chbSignUpShowPassword.OnCheck.BorderThickness = 2;
            this.chbSignUpShowPassword.OnCheck.CheckBoxColor = System.Drawing.Color.White;
            this.chbSignUpShowPassword.OnCheck.CheckmarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbSignUpShowPassword.OnCheck.CheckmarkThickness = 5;
            this.chbSignUpShowPassword.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chbSignUpShowPassword.OnDisable.BorderRadius = 2;
            this.chbSignUpShowPassword.OnDisable.BorderThickness = 2;
            this.chbSignUpShowPassword.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chbSignUpShowPassword.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chbSignUpShowPassword.OnDisable.CheckmarkThickness = 2;
            this.chbSignUpShowPassword.OnHoverChecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbSignUpShowPassword.OnHoverChecked.BorderRadius = 2;
            this.chbSignUpShowPassword.OnHoverChecked.BorderThickness = 2;
            this.chbSignUpShowPassword.OnHoverChecked.CheckBoxColor = System.Drawing.Color.White;
            this.chbSignUpShowPassword.OnHoverChecked.CheckmarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbSignUpShowPassword.OnHoverChecked.CheckmarkThickness = 5;
            this.chbSignUpShowPassword.OnHoverUnchecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbSignUpShowPassword.OnHoverUnchecked.BorderRadius = 2;
            this.chbSignUpShowPassword.OnHoverUnchecked.BorderThickness = 2;
            this.chbSignUpShowPassword.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.White;
            this.chbSignUpShowPassword.OnUncheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbSignUpShowPassword.OnUncheck.BorderRadius = 2;
            this.chbSignUpShowPassword.OnUncheck.BorderThickness = 2;
            this.chbSignUpShowPassword.OnUncheck.CheckBoxColor = System.Drawing.Color.White;
            this.chbSignUpShowPassword.Size = new System.Drawing.Size(35, 35);
            this.chbSignUpShowPassword.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chbSignUpShowPassword.TabIndex = 31;
            this.chbSignUpShowPassword.ThreeState = false;
            this.chbSignUpShowPassword.ToolTipText = null;
            this.chbSignUpShowPassword.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.chbSignUpShowPassword_CheckedChanged);
            // 
            // txtSignUpPasswordConfirm
            // 
            this.txtSignUpPasswordConfirm.AcceptsReturn = false;
            this.txtSignUpPasswordConfirm.AcceptsTab = false;
            this.txtSignUpPasswordConfirm.AnimationSpeed = 200;
            this.txtSignUpPasswordConfirm.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSignUpPasswordConfirm.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSignUpPasswordConfirm.BackColor = System.Drawing.SystemColors.Control;
            this.txtSignUpPasswordConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSignUpPasswordConfirm.BackgroundImage")));
            this.txtSignUpPasswordConfirm.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpPasswordConfirm.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtSignUpPasswordConfirm.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpPasswordConfirm.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.txtSignUpPasswordConfirm.BorderRadius = 10;
            this.txtSignUpPasswordConfirm.BorderThickness = 4;
            this.txtSignUpPasswordConfirm.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSignUpPasswordConfirm.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpPasswordConfirm.DefaultFont = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSignUpPasswordConfirm.DefaultText = "";
            this.txtSignUpPasswordConfirm.FillColor = System.Drawing.SystemColors.Control;
            this.txtSignUpPasswordConfirm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpPasswordConfirm.HideSelection = true;
            this.txtSignUpPasswordConfirm.IconLeft = null;
            this.txtSignUpPasswordConfirm.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpPasswordConfirm.IconPadding = 10;
            this.txtSignUpPasswordConfirm.IconRight = null;
            this.txtSignUpPasswordConfirm.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpPasswordConfirm.Lines = new string[0];
            this.txtSignUpPasswordConfirm.Location = new System.Drawing.Point(513, 426);
            this.txtSignUpPasswordConfirm.MaxLength = 32767;
            this.txtSignUpPasswordConfirm.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtSignUpPasswordConfirm.Modified = false;
            this.txtSignUpPasswordConfirm.Multiline = false;
            this.txtSignUpPasswordConfirm.Name = "txtSignUpPasswordConfirm";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpPasswordConfirm.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSignUpPasswordConfirm.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpPasswordConfirm.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties4.FillColor = System.Drawing.SystemColors.Control;
            stateProperties4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpPasswordConfirm.OnIdleState = stateProperties4;
            this.txtSignUpPasswordConfirm.PasswordChar = '\0';
            this.txtSignUpPasswordConfirm.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtSignUpPasswordConfirm.PlaceholderText = "123456";
            this.txtSignUpPasswordConfirm.ReadOnly = false;
            this.txtSignUpPasswordConfirm.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSignUpPasswordConfirm.SelectedText = "";
            this.txtSignUpPasswordConfirm.SelectionLength = 0;
            this.txtSignUpPasswordConfirm.SelectionStart = 0;
            this.txtSignUpPasswordConfirm.ShortcutsEnabled = true;
            this.txtSignUpPasswordConfirm.Size = new System.Drawing.Size(403, 56);
            this.txtSignUpPasswordConfirm.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtSignUpPasswordConfirm.TabIndex = 29;
            this.txtSignUpPasswordConfirm.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSignUpPasswordConfirm.TextMarginBottom = 0;
            this.txtSignUpPasswordConfirm.TextMarginLeft = 0;
            this.txtSignUpPasswordConfirm.TextMarginTop = 0;
            this.txtSignUpPasswordConfirm.TextPlaceholder = "123456";
            this.txtSignUpPasswordConfirm.UseSystemPasswordChar = false;
            this.txtSignUpPasswordConfirm.WordWrap = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label7.Location = new System.Drawing.Point(507, 381);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(270, 33);
            this.label7.TabIndex = 30;
            this.label7.Text = "Confirm Password:";
            // 
            // txtSingUpPassword
            // 
            this.txtSingUpPassword.AcceptsReturn = false;
            this.txtSingUpPassword.AcceptsTab = false;
            this.txtSingUpPassword.AnimationSpeed = 200;
            this.txtSingUpPassword.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSingUpPassword.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSingUpPassword.BackColor = System.Drawing.SystemColors.Control;
            this.txtSingUpPassword.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSingUpPassword.BackgroundImage")));
            this.txtSingUpPassword.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSingUpPassword.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtSingUpPassword.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSingUpPassword.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.txtSingUpPassword.BorderRadius = 10;
            this.txtSingUpPassword.BorderThickness = 4;
            this.txtSingUpPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSingUpPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSingUpPassword.DefaultFont = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSingUpPassword.DefaultText = "";
            this.txtSingUpPassword.FillColor = System.Drawing.SystemColors.Control;
            this.txtSingUpPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSingUpPassword.HideSelection = true;
            this.txtSingUpPassword.IconLeft = null;
            this.txtSingUpPassword.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSingUpPassword.IconPadding = 10;
            this.txtSingUpPassword.IconRight = null;
            this.txtSingUpPassword.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSingUpPassword.Lines = new string[0];
            this.txtSingUpPassword.Location = new System.Drawing.Point(42, 426);
            this.txtSingUpPassword.MaxLength = 32767;
            this.txtSingUpPassword.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtSingUpPassword.Modified = false;
            this.txtSingUpPassword.Multiline = false;
            this.txtSingUpPassword.Name = "txtSingUpPassword";
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSingUpPassword.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSingUpPassword.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSingUpPassword.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties8.FillColor = System.Drawing.SystemColors.Control;
            stateProperties8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSingUpPassword.OnIdleState = stateProperties8;
            this.txtSingUpPassword.PasswordChar = '\0';
            this.txtSingUpPassword.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtSingUpPassword.PlaceholderText = "123456";
            this.txtSingUpPassword.ReadOnly = false;
            this.txtSingUpPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSingUpPassword.SelectedText = "";
            this.txtSingUpPassword.SelectionLength = 0;
            this.txtSingUpPassword.SelectionStart = 0;
            this.txtSingUpPassword.ShortcutsEnabled = true;
            this.txtSingUpPassword.Size = new System.Drawing.Size(403, 56);
            this.txtSingUpPassword.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtSingUpPassword.TabIndex = 27;
            this.txtSingUpPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSingUpPassword.TextMarginBottom = 0;
            this.txtSingUpPassword.TextMarginLeft = 0;
            this.txtSingUpPassword.TextMarginTop = 0;
            this.txtSingUpPassword.TextPlaceholder = "123456";
            this.txtSingUpPassword.UseSystemPasswordChar = false;
            this.txtSingUpPassword.WordWrap = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label6.Location = new System.Drawing.Point(36, 381);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 33);
            this.label6.TabIndex = 28;
            this.label6.Text = "Password:";
            // 
            // txtSignUpUsername
            // 
            this.txtSignUpUsername.AcceptsReturn = false;
            this.txtSignUpUsername.AcceptsTab = false;
            this.txtSignUpUsername.AnimationSpeed = 200;
            this.txtSignUpUsername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSignUpUsername.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSignUpUsername.BackColor = System.Drawing.SystemColors.Control;
            this.txtSignUpUsername.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSignUpUsername.BackgroundImage")));
            this.txtSignUpUsername.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpUsername.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtSignUpUsername.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpUsername.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.txtSignUpUsername.BorderRadius = 10;
            this.txtSignUpUsername.BorderThickness = 4;
            this.txtSignUpUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSignUpUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpUsername.DefaultFont = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSignUpUsername.DefaultText = "";
            this.txtSignUpUsername.FillColor = System.Drawing.SystemColors.Control;
            this.txtSignUpUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpUsername.HideSelection = true;
            this.txtSignUpUsername.IconLeft = null;
            this.txtSignUpUsername.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpUsername.IconPadding = 10;
            this.txtSignUpUsername.IconRight = null;
            this.txtSignUpUsername.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpUsername.Lines = new string[0];
            this.txtSignUpUsername.Location = new System.Drawing.Point(513, 284);
            this.txtSignUpUsername.MaxLength = 32767;
            this.txtSignUpUsername.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtSignUpUsername.Modified = false;
            this.txtSignUpUsername.Multiline = false;
            this.txtSignUpUsername.Name = "txtSignUpUsername";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpUsername.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Empty;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSignUpUsername.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpUsername.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties12.FillColor = System.Drawing.SystemColors.Control;
            stateProperties12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpUsername.OnIdleState = stateProperties12;
            this.txtSignUpUsername.PasswordChar = '\0';
            this.txtSignUpUsername.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtSignUpUsername.PlaceholderText = "Enter username";
            this.txtSignUpUsername.ReadOnly = false;
            this.txtSignUpUsername.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSignUpUsername.SelectedText = "";
            this.txtSignUpUsername.SelectionLength = 0;
            this.txtSignUpUsername.SelectionStart = 0;
            this.txtSignUpUsername.ShortcutsEnabled = true;
            this.txtSignUpUsername.Size = new System.Drawing.Size(403, 56);
            this.txtSignUpUsername.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtSignUpUsername.TabIndex = 25;
            this.txtSignUpUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSignUpUsername.TextMarginBottom = 0;
            this.txtSignUpUsername.TextMarginLeft = 0;
            this.txtSignUpUsername.TextMarginTop = 0;
            this.txtSignUpUsername.TextPlaceholder = "Enter username";
            this.txtSignUpUsername.UseSystemPasswordChar = false;
            this.txtSignUpUsername.WordWrap = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label8.Location = new System.Drawing.Point(507, 248);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 33);
            this.label8.TabIndex = 26;
            this.label8.Text = "Username:";
            // 
            // txtSignUpEmail
            // 
            this.txtSignUpEmail.AcceptsReturn = false;
            this.txtSignUpEmail.AcceptsTab = false;
            this.txtSignUpEmail.AnimationSpeed = 200;
            this.txtSignUpEmail.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSignUpEmail.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSignUpEmail.BackColor = System.Drawing.SystemColors.Control;
            this.txtSignUpEmail.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSignUpEmail.BackgroundImage")));
            this.txtSignUpEmail.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpEmail.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtSignUpEmail.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpEmail.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.txtSignUpEmail.BorderRadius = 10;
            this.txtSignUpEmail.BorderThickness = 4;
            this.txtSignUpEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSignUpEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpEmail.DefaultFont = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSignUpEmail.DefaultText = "";
            this.txtSignUpEmail.FillColor = System.Drawing.SystemColors.Control;
            this.txtSignUpEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpEmail.HideSelection = true;
            this.txtSignUpEmail.IconLeft = null;
            this.txtSignUpEmail.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpEmail.IconPadding = 10;
            this.txtSignUpEmail.IconRight = null;
            this.txtSignUpEmail.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpEmail.Lines = new string[0];
            this.txtSignUpEmail.Location = new System.Drawing.Point(42, 284);
            this.txtSignUpEmail.MaxLength = 32767;
            this.txtSignUpEmail.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtSignUpEmail.Modified = false;
            this.txtSignUpEmail.Multiline = false;
            this.txtSignUpEmail.Name = "txtSignUpEmail";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpEmail.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Empty;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSignUpEmail.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpEmail.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties16.FillColor = System.Drawing.SystemColors.Control;
            stateProperties16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpEmail.OnIdleState = stateProperties16;
            this.txtSignUpEmail.PasswordChar = '\0';
            this.txtSignUpEmail.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtSignUpEmail.PlaceholderText = "someone@example.com";
            this.txtSignUpEmail.ReadOnly = false;
            this.txtSignUpEmail.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSignUpEmail.SelectedText = "";
            this.txtSignUpEmail.SelectionLength = 0;
            this.txtSignUpEmail.SelectionStart = 0;
            this.txtSignUpEmail.ShortcutsEnabled = true;
            this.txtSignUpEmail.Size = new System.Drawing.Size(403, 56);
            this.txtSignUpEmail.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtSignUpEmail.TabIndex = 23;
            this.txtSignUpEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSignUpEmail.TextMarginBottom = 0;
            this.txtSignUpEmail.TextMarginLeft = 0;
            this.txtSignUpEmail.TextMarginTop = 0;
            this.txtSignUpEmail.TextPlaceholder = "someone@example.com";
            this.txtSignUpEmail.UseSystemPasswordChar = false;
            this.txtSignUpEmail.WordWrap = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label5.Location = new System.Drawing.Point(37, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 33);
            this.label5.TabIndex = 24;
            this.label5.Text = "Email:";
            // 
            // txtSignUpSurname
            // 
            this.txtSignUpSurname.AcceptsReturn = false;
            this.txtSignUpSurname.AcceptsTab = false;
            this.txtSignUpSurname.AnimationSpeed = 200;
            this.txtSignUpSurname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSignUpSurname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSignUpSurname.BackColor = System.Drawing.SystemColors.Control;
            this.txtSignUpSurname.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSignUpSurname.BackgroundImage")));
            this.txtSignUpSurname.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpSurname.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtSignUpSurname.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpSurname.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.txtSignUpSurname.BorderRadius = 10;
            this.txtSignUpSurname.BorderThickness = 4;
            this.txtSignUpSurname.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSignUpSurname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpSurname.DefaultFont = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSignUpSurname.DefaultText = "";
            this.txtSignUpSurname.FillColor = System.Drawing.SystemColors.Control;
            this.txtSignUpSurname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpSurname.HideSelection = true;
            this.txtSignUpSurname.IconLeft = null;
            this.txtSignUpSurname.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpSurname.IconPadding = 10;
            this.txtSignUpSurname.IconRight = null;
            this.txtSignUpSurname.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpSurname.Lines = new string[0];
            this.txtSignUpSurname.Location = new System.Drawing.Point(513, 152);
            this.txtSignUpSurname.MaxLength = 32767;
            this.txtSignUpSurname.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtSignUpSurname.Modified = false;
            this.txtSignUpSurname.Multiline = false;
            this.txtSignUpSurname.Name = "txtSignUpSurname";
            stateProperties17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpSurname.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.Empty;
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.Empty;
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSignUpSurname.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpSurname.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties20.FillColor = System.Drawing.SystemColors.Control;
            stateProperties20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpSurname.OnIdleState = stateProperties20;
            this.txtSignUpSurname.PasswordChar = '\0';
            this.txtSignUpSurname.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtSignUpSurname.PlaceholderText = "Enter surname";
            this.txtSignUpSurname.ReadOnly = false;
            this.txtSignUpSurname.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSignUpSurname.SelectedText = "";
            this.txtSignUpSurname.SelectionLength = 0;
            this.txtSignUpSurname.SelectionStart = 0;
            this.txtSignUpSurname.ShortcutsEnabled = true;
            this.txtSignUpSurname.Size = new System.Drawing.Size(403, 56);
            this.txtSignUpSurname.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtSignUpSurname.TabIndex = 21;
            this.txtSignUpSurname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSignUpSurname.TextMarginBottom = 0;
            this.txtSignUpSurname.TextMarginLeft = 0;
            this.txtSignUpSurname.TextMarginTop = 0;
            this.txtSignUpSurname.TextPlaceholder = "Enter surname";
            this.txtSignUpSurname.UseSystemPasswordChar = false;
            this.txtSignUpSurname.WordWrap = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label4.Location = new System.Drawing.Point(507, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 33);
            this.label4.TabIndex = 22;
            this.label4.Text = "Surname:";
            // 
            // txtSignUpName
            // 
            this.txtSignUpName.AcceptsReturn = false;
            this.txtSignUpName.AcceptsTab = false;
            this.txtSignUpName.AnimationSpeed = 200;
            this.txtSignUpName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSignUpName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSignUpName.BackColor = System.Drawing.SystemColors.Control;
            this.txtSignUpName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSignUpName.BackgroundImage")));
            this.txtSignUpName.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtSignUpName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpName.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.txtSignUpName.BorderRadius = 10;
            this.txtSignUpName.BorderThickness = 4;
            this.txtSignUpName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSignUpName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpName.DefaultFont = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSignUpName.DefaultText = "";
            this.txtSignUpName.FillColor = System.Drawing.SystemColors.Control;
            this.txtSignUpName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtSignUpName.HideSelection = true;
            this.txtSignUpName.IconLeft = null;
            this.txtSignUpName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpName.IconPadding = 10;
            this.txtSignUpName.IconRight = null;
            this.txtSignUpName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSignUpName.Lines = new string[0];
            this.txtSignUpName.Location = new System.Drawing.Point(42, 152);
            this.txtSignUpName.MaxLength = 32767;
            this.txtSignUpName.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtSignUpName.Modified = false;
            this.txtSignUpName.Multiline = false;
            this.txtSignUpName.Name = "txtSignUpName";
            stateProperties21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpName.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.Empty;
            stateProperties22.FillColor = System.Drawing.Color.White;
            stateProperties22.ForeColor = System.Drawing.Color.Empty;
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSignUpName.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpName.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties24.FillColor = System.Drawing.SystemColors.Control;
            stateProperties24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSignUpName.OnIdleState = stateProperties24;
            this.txtSignUpName.PasswordChar = '\0';
            this.txtSignUpName.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtSignUpName.PlaceholderText = "Enter name";
            this.txtSignUpName.ReadOnly = false;
            this.txtSignUpName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSignUpName.SelectedText = "";
            this.txtSignUpName.SelectionLength = 0;
            this.txtSignUpName.SelectionStart = 0;
            this.txtSignUpName.ShortcutsEnabled = true;
            this.txtSignUpName.Size = new System.Drawing.Size(403, 56);
            this.txtSignUpName.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtSignUpName.TabIndex = 18;
            this.txtSignUpName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSignUpName.TextMarginBottom = 0;
            this.txtSignUpName.TextMarginLeft = 0;
            this.txtSignUpName.TextMarginTop = 0;
            this.txtSignUpName.TextPlaceholder = "Enter name";
            this.txtSignUpName.UseSystemPasswordChar = false;
            this.txtSignUpName.WordWrap = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label3.Location = new System.Drawing.Point(37, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 33);
            this.label3.TabIndex = 20;
            this.label3.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Consolas", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label2.Location = new System.Drawing.Point(33, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 56);
            this.label2.TabIndex = 19;
            this.label2.Text = "Sign Up";
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 771);
            this.Controls.Add(this.panelSignUpRight);
            this.Controls.Add(this.panelSignUpLeft);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SignUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SignUp";
            this.Load += new System.EventHandler(this.SignUp_Load);
            this.panelSignUpLeft.ResumeLayout(false);
            this.panelSignUpLeft.PerformLayout();
            this.panelSignUpRight.ResumeLayout(false);
            this.panelSignUpRight.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSignUpLeft;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelSignUpRight;
        private Bunifu.UI.WinForms.BunifuCheckBox chbSignUpShowPassword;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSignUpPasswordConfirm;
        private System.Windows.Forms.Label label7;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSingUpPassword;
        private System.Windows.Forms.Label label6;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSignUpUsername;
        private System.Windows.Forms.Label label8;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSignUpEmail;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSignUpSurname;
        private System.Windows.Forms.Label label4;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSignUpName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private Bunifu.UI.WinForms.BunifuCheckBox chbAgreeTerms;
        private System.Windows.Forms.Label label9;
        private Guna.UI.WinForms.GunaButton btnSignUp;
        private System.Windows.Forms.Label minimizeSignUp;
        private System.Windows.Forms.Label closeSignUp;
        private Guna.UI.WinForms.GunaButton btnSignUpCancel;
    }
}