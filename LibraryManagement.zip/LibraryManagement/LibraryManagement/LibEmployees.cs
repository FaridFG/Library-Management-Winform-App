﻿using Bunifu.UI.WinForms.BunifuTextbox;
using LibraryManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagement
{
    public partial class LibEmployees : Form
    {
        private LibraryEntities _db;
        private Form _login;
        private string login;
        public LibEmployees(Form form, BunifuTextBox txt)
        {
            InitializeComponent();
            _db = new LibraryEntities();
            _login = form;
            login = txt.Text.Trim();
        }

        private void closeEmployeePage_Click(object sender, EventArgs e)
        {
            this.Close();
            _login.Show();
        }

        private void minimizeEmployeePage_Click(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
        }

        private void LibEmployees_Load(object sender, EventArgs e)
        {
            Employee employee = _db.Employees.First(em => em.Email == login || em.Username == login);
            lblUser.Text = employee.Name + " " + employee.Surname;

            pnlEmployeeBooks.BringToFront();

            FillAll();
        }

        private void btnEmployeeBooks_Click(object sender, EventArgs e)
        {
            pnlEmployeeBooks.BringToFront();
            dgvEmployeeBooks.DataSource = _db.Books.Select(b => new
            {
                b.Id,
                b.Name,
                b.Price,
                b.Quantity,
                Genre = b.Genre.Name,
                Author = b.Author.FullName
            }).ToArray();
        }

        private void btnEmployeeRentBook_Click(object sender, EventArgs e)
        {
            pnlEmployeeRents.BringToFront();
        }

        private void FillAll()
        {
            dgvEmployeeBooks.DataSource = _db.Books.Select(b => new
            {
                b.Id,
                b.Name,
                b.Price,
                b.Quantity,
                Genre = b.Genre.Name,
                Author = b.Author.FullName
            }).ToArray();

            cmbEmployeeRentBook.Items.AddRange(_db.Books.Where(b => b.Quantity > 0).Select(b => new CmbBooks
            {
                Id = b.Id,
                Name = b.Name,
                Quantity = b.Quantity
            }).ToArray());

            cmbEmployeeCustomerNames.Items.AddRange(_db.Customers.Select(c => new CmbCustomer
            {
                Id = c.Id,
                Name = c.Name,
                Surname = c.Surname
            }).ToArray());

            var months = System.Globalization.DateTimeFormatInfo.InvariantInfo.MonthNames;
            cmbReturnMonth.Items.AddRange(months);

            cmbEmployeeReturnCustomer.Items.AddRange(_db.Customers.Select(c => new CmbCustomer
            {
                Id = c.Id,
                Name = c.Name,
                Surname = c.Surname
            }).ToArray());

            cmbReturnYear.Items.Add(DateTime.Now.Year);
            cmbReturnYear.Items.Add(DateTime.Now.Year + 1);

            DateTime today = DateTime.Today;
            cmbReturnDate.Items.Add(today);
        }

        private void AddBooks_Click(object sender, EventArgs e)
        {
            CmbBooks book = (CmbBooks)cmbEmployeeRentBook.SelectedItem;
            int quantity = int.Parse(numBook.Value.ToString());

            if (cmbEmployeeCustomerNames.SelectedItem == null || book == null || quantity == 0)
            {
                MyMsgBox msg = new MyMsgBox("Please, fill out all fields above");
                msg.ShowDialog();
                return;
            }

            bool exist = true;

            foreach (LsBooks b in lstAddedBooks.Items)
            {
                if (b.Id == book.Id)
                {
                    lstAddedBooks.Items.Remove(b);
                    b.Quantity += quantity;
                    lstAddedBooks.Items.Add(b);
                    exist = false;
                    break;
                }
            }
            if (exist)
            {
                lstAddedBooks.Items.Add(new LsBooks
                {
                    Id = book.Id,
                    Name = book.Name,
                    Price = book.Price,
                    Quantity = quantity
                }).ToString();
            }

            cmbEmployeeRentBook.SelectedItem = null;
            numBook.Value = 0;
        }

        private async void btnEmployeeRentConfirm_Click(object sender, EventArgs e)
        {
            int quantity = int.Parse(numBook.Value.ToString());
            DateTime date = DateTime.Today;
            var employee = _db.Employees.FirstOrDefault(em => em.Email == login || em.Username == login);
            string dueDate = cmbReturnYear.SelectedItem + "-" + (cmbReturnMonth.SelectedIndex + 1) + "-" + cmbReturnDay.SelectedItem;

            if (cmbReturnYear.SelectedItem == null || cmbReturnMonth.SelectedItem == null || cmbReturnDay.SelectedItem == null || lstAddedBooks.Items.Count == 0)
            {
                MyMsgBox msg = new MyMsgBox("Please, fill out the fields and then click on Rent button");
                msg.ShowDialog();
                return;
            }

            Rent rent = new Rent()
            {
                RentTime = date,
                RentDue = Convert.ToDateTime(dueDate),
                CustomerId = ((CmbCustomer)cmbEmployeeCustomerNames.SelectedItem).Id,
                EmployeeId = employee.Id,
            };

            foreach (LsBooks book in lstAddedBooks.Items)
            {
                rent.RentBooks.Add(new RentBook
                {
                    RentId = rent.Id,
                    BookId = book.Id,
                    BookQuantity = book.Quantity
                });
            }

            _db.Rents.Add(rent);
            await _db.SaveChangesAsync();
            DecreaseBooks();

            MyMsgBox message = new MyMsgBox("Congratulations! You have successfully rented books.");
            message.ShowDialog();

            cmbEmployeeCustomerNames.SelectedItem = null;
            cmbReturnYear.Items.Clear();
            cmbReturnYear.Items.Add(DateTime.Now.Year);
            cmbReturnYear.Items.Add(DateTime.Now.Year + 1);
            cmbReturnMonth.Items.Clear();
            var months = System.Globalization.DateTimeFormatInfo.InvariantInfo.MonthNames;
            cmbReturnMonth.Items.AddRange(months);
            cmbReturnDay.SelectedItem = null;
            lstAddedBooks.Items.Clear();
        }

        private async void DecreaseBooks()
        {
            foreach (LsBooks books in lstAddedBooks.Items)
            {
                Book book = _db.Books.First(b => b.Id == books.Id);
                book.Quantity -= books.Quantity;
                await _db.SaveChangesAsync();
            }
        }

        private void btnEmployeeSearch_Click(object sender, EventArgs e)
        {
            pnlSearchBook.BringToFront();
        }

        private void btnEmployeeSearchBooks_Click(object sender, EventArgs e)
        {
            string name = txtEmployeeSearch.Text.Trim();
            Book book = _db.Books.FirstOrDefault(b => b.Name.ToLower() == name.ToLower());

            if (book == null)
            {
                dgvEmployeeSearchResult.DataSource = "";
                MyMsgBox msg = new MyMsgBox("Sorry, we do not have this book in our Library");
                msg.ShowDialog();
                return;
            }
            else
            {
                dgvEmployeeSearchResult.DataSource = _db.Books.Where(b => b.Name == name).Select(b => new
                {
                    b.Id,
                    b.Name,
                    b.Price,
                    b.Quantity,
                    Genre = b.Genre.Name,
                    Author = b.Author.FullName
                }).ToArray();
            }
        }

        private void cmbReturnMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            int year = int.Parse(cmbReturnYear.SelectedItem.ToString());
            int month = (cmbReturnMonth.SelectedIndex + 1);
            int[] days = Enumerable.Range(1, DateTime.DaysInMonth(year, month)).ToArray();

            cmbReturnDay.DataSource = days;
        }

        private void cmbReturnYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbReturnMonth.SelectedIndex = 0;
        }

        private void btnEmployeeReturnBook_Click(object sender, EventArgs e)
        {
            pnlBookReturn.BringToFront();
        }

        private void btnEmployeeReturnBooks_Click(object sender, EventArgs e)
        {
            int Id = ((CmbCustomer)cmbEmployeeReturnCustomer.SelectedItem).Id;
            Rent rent = _db.Rents.First(r => r.CustomerId == Id);
            _db.Rents.Remove(rent); 
        }
    }
}