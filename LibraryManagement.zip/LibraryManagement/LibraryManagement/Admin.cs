﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagement
{
    public partial class Admin : Form
    {
        private Form _login;
        public Admin(Form form)
        {
            InitializeComponent();
            _login = form;
        }
    }
}
