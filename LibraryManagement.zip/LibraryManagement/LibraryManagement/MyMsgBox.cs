﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagement
{
    public partial class MyMsgBox : Form
    {
        public MyMsgBox(string message)
        {
            InitializeComponent();
            lblMessage.Text = message;
        }

        private void btnMessageBoxCancel_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void btnMessageBoxRetry_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void closeMessageBox_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void minimizeMessageBox_Click(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.08;
            }
            else
            {
                timer1.Stop();
                Application.Exit();
            }
        }
    }
}
