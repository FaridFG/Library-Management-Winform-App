﻿namespace LibraryManagement
{
    partial class MyMsgBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelMessageBoxTop = new System.Windows.Forms.Panel();
            this.minimizeMessageBox = new System.Windows.Forms.Label();
            this.closeMessageBox = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMessageBoxRetry = new Guna.UI.WinForms.GunaButton();
            this.btnMessageBoxCancel = new Guna.UI.WinForms.GunaButton();
            this.lblMessage = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelMessageBoxTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMessageBoxTop
            // 
            this.panelMessageBoxTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.panelMessageBoxTop.Controls.Add(this.minimizeMessageBox);
            this.panelMessageBoxTop.Controls.Add(this.closeMessageBox);
            this.panelMessageBoxTop.Controls.Add(this.label1);
            this.panelMessageBoxTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMessageBoxTop.Location = new System.Drawing.Point(0, 0);
            this.panelMessageBoxTop.Name = "panelMessageBoxTop";
            this.panelMessageBoxTop.Size = new System.Drawing.Size(1161, 104);
            this.panelMessageBoxTop.TabIndex = 0;
            // 
            // minimizeMessageBox
            // 
            this.minimizeMessageBox.AutoSize = true;
            this.minimizeMessageBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimizeMessageBox.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimizeMessageBox.ForeColor = System.Drawing.Color.White;
            this.minimizeMessageBox.Location = new System.Drawing.Point(994, 0);
            this.minimizeMessageBox.Name = "minimizeMessageBox";
            this.minimizeMessageBox.Size = new System.Drawing.Size(59, 67);
            this.minimizeMessageBox.TabIndex = 2;
            this.minimizeMessageBox.Text = "_";
            this.minimizeMessageBox.Click += new System.EventHandler(this.minimizeMessageBox_Click);
            // 
            // closeMessageBox
            // 
            this.closeMessageBox.AutoSize = true;
            this.closeMessageBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeMessageBox.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeMessageBox.ForeColor = System.Drawing.Color.White;
            this.closeMessageBox.Location = new System.Drawing.Point(1059, 9);
            this.closeMessageBox.Name = "closeMessageBox";
            this.closeMessageBox.Size = new System.Drawing.Size(64, 67);
            this.closeMessageBox.TabIndex = 1;
            this.closeMessageBox.Text = "X";
            this.closeMessageBox.Click += new System.EventHandler(this.closeMessageBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(28, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(217, 67);
            this.label1.TabIndex = 0;
            this.label1.Text = "Warning";
            // 
            // btnMessageBoxRetry
            // 
            this.btnMessageBoxRetry.AnimationHoverSpeed = 0.7F;
            this.btnMessageBoxRetry.AnimationSpeed = 0.7F;
            this.btnMessageBoxRetry.BackColor = System.Drawing.Color.Transparent;
            this.btnMessageBoxRetry.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMessageBoxRetry.BorderColor = System.Drawing.Color.Black;
            this.btnMessageBoxRetry.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMessageBoxRetry.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnMessageBoxRetry.FocusedColor = System.Drawing.Color.Empty;
            this.btnMessageBoxRetry.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMessageBoxRetry.ForeColor = System.Drawing.Color.White;
            this.btnMessageBoxRetry.Image = null;
            this.btnMessageBoxRetry.ImageSize = new System.Drawing.Size(20, 20);
            this.btnMessageBoxRetry.Location = new System.Drawing.Point(102, 461);
            this.btnMessageBoxRetry.Name = "btnMessageBoxRetry";
            this.btnMessageBoxRetry.OnHoverBaseColor = System.Drawing.Color.Blue;
            this.btnMessageBoxRetry.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnMessageBoxRetry.OnHoverForeColor = System.Drawing.Color.White;
            this.btnMessageBoxRetry.OnHoverImage = null;
            this.btnMessageBoxRetry.OnPressedColor = System.Drawing.Color.Black;
            this.btnMessageBoxRetry.OnPressedDepth = 35;
            this.btnMessageBoxRetry.Radius = 30;
            this.btnMessageBoxRetry.Size = new System.Drawing.Size(352, 90);
            this.btnMessageBoxRetry.TabIndex = 1;
            this.btnMessageBoxRetry.Text = "Retry";
            this.btnMessageBoxRetry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnMessageBoxRetry.Click += new System.EventHandler(this.btnMessageBoxRetry_Click);
            // 
            // btnMessageBoxCancel
            // 
            this.btnMessageBoxCancel.AnimationHoverSpeed = 0.7F;
            this.btnMessageBoxCancel.AnimationSpeed = 0.7F;
            this.btnMessageBoxCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnMessageBoxCancel.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnMessageBoxCancel.BorderColor = System.Drawing.Color.Black;
            this.btnMessageBoxCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMessageBoxCancel.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnMessageBoxCancel.FocusedColor = System.Drawing.Color.Empty;
            this.btnMessageBoxCancel.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMessageBoxCancel.ForeColor = System.Drawing.Color.White;
            this.btnMessageBoxCancel.Image = null;
            this.btnMessageBoxCancel.ImageSize = new System.Drawing.Size(20, 20);
            this.btnMessageBoxCancel.Location = new System.Drawing.Point(683, 461);
            this.btnMessageBoxCancel.Name = "btnMessageBoxCancel";
            this.btnMessageBoxCancel.OnHoverBaseColor = System.Drawing.Color.Blue;
            this.btnMessageBoxCancel.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnMessageBoxCancel.OnHoverForeColor = System.Drawing.Color.White;
            this.btnMessageBoxCancel.OnHoverImage = null;
            this.btnMessageBoxCancel.OnPressedColor = System.Drawing.Color.Black;
            this.btnMessageBoxCancel.OnPressedDepth = 35;
            this.btnMessageBoxCancel.Radius = 30;
            this.btnMessageBoxCancel.Size = new System.Drawing.Size(352, 90);
            this.btnMessageBoxCancel.TabIndex = 2;
            this.btnMessageBoxCancel.Text = "Cancel";
            this.btnMessageBoxCancel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnMessageBoxCancel.Click += new System.EventHandler(this.btnMessageBoxCancel_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblMessage.Location = new System.Drawing.Point(40, 142);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(1083, 276);
            this.lblMessage.TabIndex = 3;
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // MyMsgBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1161, 606);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.btnMessageBoxCancel);
            this.Controls.Add(this.btnMessageBoxRetry);
            this.Controls.Add(this.panelMessageBoxTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MyMsgBox";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MyMsgBox";
            this.panelMessageBoxTop.ResumeLayout(false);
            this.panelMessageBoxTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMessageBoxTop;
        private System.Windows.Forms.Label minimizeMessageBox;
        private System.Windows.Forms.Label closeMessageBox;
        private System.Windows.Forms.Label label1;
        private Guna.UI.WinForms.GunaButton btnMessageBoxRetry;
        private Guna.UI.WinForms.GunaButton btnMessageBoxCancel;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Timer timer1;
    }
}