﻿using LibraryManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagement
{
    public partial class LogIn : Form
    {
        private LibraryEntities _db;
        public LogIn()
        {
            InitializeComponent();
            _db = new LibraryEntities();
        }

        private void closeLogIn_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void minimizeLogIn_Click(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
        }

        private void lblGoSignUp_Click(object sender, EventArgs e)
        {
            SignUp signUpPage = new SignUp(this);
            signUpPage.Show();
            this.Hide();
        }

        private void chbLogInShowPassword_CheckedChanged(object sender, Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs e)
        {
            if (chbLogInShowPassword.Checked)
            {
                txtLogInPassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtLogInPassword.UseSystemPasswordChar = true;
            }
        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            txtLogInPassword.UseSystemPasswordChar = true;
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string login = txtLogInEmailUsername.Text.Trim();
            string password = txtLogInPassword.Text.Trim().HashPassword();

            if (login == "" || password == "")
            {
                MyMsgBox msg = new MyMsgBox("Please, fill out all the fields.");
                msg.ShowDialog();
                return;
            }

            if (!(_db.Employees.Any(em => em.Email == login || em.Username == login)))
            {
                MyMsgBox msg = new MyMsgBox("Incorrect email or username. Tap Retry button to try again!");
                msg.ShowDialog();
                return;
            }

            if (_db.Employees.Any(em => (em.Email == login || em.Username == login) && em.Password != password))
            {
                MyMsgBox msg = new MyMsgBox("Password is incorrect. Tap Retry button to try again!");
                msg.ShowDialog();
                return;
            }

            if (_db.Employees.Any(em => (em.Email == login || em.Username == login) && em.Password == password && em.isAdmin == true))
            {
                Admin adminPage = new Admin(this);
                adminPage.Show();
                this.Hide();
                ClearAll();
            }

            if (_db.Employees.Any(em => (em.Email == login || em.Username == login) && em.Password == password && em.isDeleted == true))
            {
                MyMsgBox msg = new MyMsgBox("This account has been deleted");
                msg.ShowDialog();
                return;
            }

            if (_db.Employees.Any(em => (em.Email == login || em.Username == login) && em.Password == password && em.isConfirmed == false))
            {
                MyMsgBox msg = new MyMsgBox("Please, wait for admin confirmation.");
                msg.ShowDialog();
                return;
            }

            if (_db.Employees.Any(em => (em.Email == login || em.Username == login) && em.Password == password && em.isAdmin == false))
            {
                LibEmployees employeePage = new LibEmployees(this, txtLogInEmailUsername);
                employeePage.Show();
                this.Hide();
                ClearAll();
            }
        }

        public void ClearAll()
        {
            txtLogInEmailUsername.Text = "";
            txtLogInPassword.Text = "";
            chbLogInShowPassword.Checked = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.05;
            }
            else
            {
                timer1.Stop();
                Application.Exit();
            }
        }
    }
}
