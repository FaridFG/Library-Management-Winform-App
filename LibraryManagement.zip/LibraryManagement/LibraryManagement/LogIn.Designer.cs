﻿namespace LibraryManagement
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogIn));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.panelSignUpLeft = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.minimizeLogIn = new System.Windows.Forms.Label();
            this.closeLogIn = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLogInPassword = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLogInEmailUsername = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.chbLogInShowPassword = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.btnLogIn = new Guna.UI.WinForms.GunaButton();
            this.label4 = new System.Windows.Forms.Label();
            this.lblGoSignUp = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelSignUpLeft.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSignUpLeft
            // 
            this.panelSignUpLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.panelSignUpLeft.Controls.Add(this.label1);
            this.panelSignUpLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSignUpLeft.Location = new System.Drawing.Point(0, 0);
            this.panelSignUpLeft.Name = "panelSignUpLeft";
            this.panelSignUpLeft.Size = new System.Drawing.Size(379, 811);
            this.panelSignUpLeft.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(348, 420);
            this.label1.TabIndex = 0;
            this.label1.Text = "  Reading\r\n     is\r\n Dreaming\r\nWith Open\r\n    Eyes";
            // 
            // minimizeLogIn
            // 
            this.minimizeLogIn.AutoSize = true;
            this.minimizeLogIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimizeLogIn.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimizeLogIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.minimizeLogIn.Location = new System.Drawing.Point(942, 1);
            this.minimizeLogIn.Name = "minimizeLogIn";
            this.minimizeLogIn.Size = new System.Drawing.Size(59, 67);
            this.minimizeLogIn.TabIndex = 41;
            this.minimizeLogIn.Text = "_";
            this.minimizeLogIn.Click += new System.EventHandler(this.minimizeLogIn_Click);
            // 
            // closeLogIn
            // 
            this.closeLogIn.AutoSize = true;
            this.closeLogIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeLogIn.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeLogIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.closeLogIn.Location = new System.Drawing.Point(993, 9);
            this.closeLogIn.Name = "closeLogIn";
            this.closeLogIn.Size = new System.Drawing.Size(64, 67);
            this.closeLogIn.TabIndex = 40;
            this.closeLogIn.Text = "X";
            this.closeLogIn.Click += new System.EventHandler(this.closeLogIn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Consolas", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label2.Location = new System.Drawing.Point(407, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 56);
            this.label2.TabIndex = 39;
            this.label2.Text = "Log In";
            // 
            // txtLogInPassword
            // 
            this.txtLogInPassword.AcceptsReturn = false;
            this.txtLogInPassword.AcceptsTab = false;
            this.txtLogInPassword.AnimationSpeed = 200;
            this.txtLogInPassword.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtLogInPassword.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtLogInPassword.BackColor = System.Drawing.SystemColors.Control;
            this.txtLogInPassword.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtLogInPassword.BackgroundImage")));
            this.txtLogInPassword.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtLogInPassword.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtLogInPassword.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtLogInPassword.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.txtLogInPassword.BorderRadius = 10;
            this.txtLogInPassword.BorderThickness = 4;
            this.txtLogInPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtLogInPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLogInPassword.DefaultFont = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogInPassword.DefaultText = "";
            this.txtLogInPassword.FillColor = System.Drawing.SystemColors.Control;
            this.txtLogInPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtLogInPassword.HideSelection = true;
            this.txtLogInPassword.IconLeft = null;
            this.txtLogInPassword.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLogInPassword.IconPadding = 10;
            this.txtLogInPassword.IconRight = null;
            this.txtLogInPassword.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLogInPassword.Lines = new string[0];
            this.txtLogInPassword.Location = new System.Drawing.Point(487, 324);
            this.txtLogInPassword.MaxLength = 32767;
            this.txtLogInPassword.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtLogInPassword.Modified = false;
            this.txtLogInPassword.Multiline = false;
            this.txtLogInPassword.Name = "txtLogInPassword";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLogInPassword.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtLogInPassword.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLogInPassword.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties4.FillColor = System.Drawing.SystemColors.Control;
            stateProperties4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLogInPassword.OnIdleState = stateProperties4;
            this.txtLogInPassword.PasswordChar = '\0';
            this.txtLogInPassword.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtLogInPassword.PlaceholderText = "123456";
            this.txtLogInPassword.ReadOnly = false;
            this.txtLogInPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLogInPassword.SelectedText = "";
            this.txtLogInPassword.SelectionLength = 0;
            this.txtLogInPassword.SelectionStart = 0;
            this.txtLogInPassword.ShortcutsEnabled = true;
            this.txtLogInPassword.Size = new System.Drawing.Size(495, 56);
            this.txtLogInPassword.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtLogInPassword.TabIndex = 44;
            this.txtLogInPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtLogInPassword.TextMarginBottom = 0;
            this.txtLogInPassword.TextMarginLeft = 0;
            this.txtLogInPassword.TextMarginTop = 0;
            this.txtLogInPassword.TextPlaceholder = "123456";
            this.txtLogInPassword.UseSystemPasswordChar = false;
            this.txtLogInPassword.WordWrap = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label6.Location = new System.Drawing.Point(481, 279);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 33);
            this.label6.TabIndex = 45;
            this.label6.Text = "Password:";
            // 
            // txtLogInEmailUsername
            // 
            this.txtLogInEmailUsername.AcceptsReturn = false;
            this.txtLogInEmailUsername.AcceptsTab = false;
            this.txtLogInEmailUsername.AnimationSpeed = 200;
            this.txtLogInEmailUsername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtLogInEmailUsername.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtLogInEmailUsername.BackColor = System.Drawing.SystemColors.Control;
            this.txtLogInEmailUsername.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtLogInEmailUsername.BackgroundImage")));
            this.txtLogInEmailUsername.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtLogInEmailUsername.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtLogInEmailUsername.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtLogInEmailUsername.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.txtLogInEmailUsername.BorderRadius = 10;
            this.txtLogInEmailUsername.BorderThickness = 4;
            this.txtLogInEmailUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtLogInEmailUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLogInEmailUsername.DefaultFont = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogInEmailUsername.DefaultText = "";
            this.txtLogInEmailUsername.FillColor = System.Drawing.SystemColors.Control;
            this.txtLogInEmailUsername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.txtLogInEmailUsername.HideSelection = true;
            this.txtLogInEmailUsername.IconLeft = null;
            this.txtLogInEmailUsername.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLogInEmailUsername.IconPadding = 10;
            this.txtLogInEmailUsername.IconRight = null;
            this.txtLogInEmailUsername.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLogInEmailUsername.Lines = new string[0];
            this.txtLogInEmailUsername.Location = new System.Drawing.Point(487, 184);
            this.txtLogInEmailUsername.MaxLength = 32767;
            this.txtLogInEmailUsername.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtLogInEmailUsername.Modified = false;
            this.txtLogInEmailUsername.Multiline = false;
            this.txtLogInEmailUsername.Name = "txtLogInEmailUsername";
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLogInEmailUsername.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtLogInEmailUsername.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLogInEmailUsername.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties8.FillColor = System.Drawing.SystemColors.Control;
            stateProperties8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLogInEmailUsername.OnIdleState = stateProperties8;
            this.txtLogInEmailUsername.PasswordChar = '\0';
            this.txtLogInEmailUsername.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.txtLogInEmailUsername.PlaceholderText = "Enter email or username";
            this.txtLogInEmailUsername.ReadOnly = false;
            this.txtLogInEmailUsername.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLogInEmailUsername.SelectedText = "";
            this.txtLogInEmailUsername.SelectionLength = 0;
            this.txtLogInEmailUsername.SelectionStart = 0;
            this.txtLogInEmailUsername.ShortcutsEnabled = true;
            this.txtLogInEmailUsername.Size = new System.Drawing.Size(495, 56);
            this.txtLogInEmailUsername.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtLogInEmailUsername.TabIndex = 42;
            this.txtLogInEmailUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtLogInEmailUsername.TextMarginBottom = 0;
            this.txtLogInEmailUsername.TextMarginLeft = 0;
            this.txtLogInEmailUsername.TextMarginTop = 0;
            this.txtLogInEmailUsername.TextPlaceholder = "Enter email or username";
            this.txtLogInEmailUsername.UseSystemPasswordChar = false;
            this.txtLogInEmailUsername.WordWrap = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label3.Location = new System.Drawing.Point(482, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(285, 33);
            this.label3.TabIndex = 43;
            this.label3.Text = "Email or Username:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label9.Location = new System.Drawing.Point(529, 432);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(315, 33);
            this.label9.TabIndex = 47;
            this.label9.Text = "Show / Hide Password";
            // 
            // chbLogInShowPassword
            // 
            this.chbLogInShowPassword.AllowBindingControlAnimation = true;
            this.chbLogInShowPassword.AllowBindingControlColorChanges = false;
            this.chbLogInShowPassword.AllowBindingControlLocation = true;
            this.chbLogInShowPassword.AllowCheckBoxAnimation = true;
            this.chbLogInShowPassword.AllowCheckmarkAnimation = true;
            this.chbLogInShowPassword.AllowOnHoverStates = true;
            this.chbLogInShowPassword.AutoCheck = true;
            this.chbLogInShowPassword.BackColor = System.Drawing.Color.Transparent;
            this.chbLogInShowPassword.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chbLogInShowPassword.BackgroundImage")));
            this.chbLogInShowPassword.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chbLogInShowPassword.BindingControl = null;
            this.chbLogInShowPassword.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chbLogInShowPassword.Checked = false;
            this.chbLogInShowPassword.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Unchecked;
            this.chbLogInShowPassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chbLogInShowPassword.CustomCheckmarkImage = null;
            this.chbLogInShowPassword.Location = new System.Drawing.Point(488, 430);
            this.chbLogInShowPassword.MinimumSize = new System.Drawing.Size(17, 17);
            this.chbLogInShowPassword.Name = "chbLogInShowPassword";
            this.chbLogInShowPassword.OnCheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbLogInShowPassword.OnCheck.BorderRadius = 2;
            this.chbLogInShowPassword.OnCheck.BorderThickness = 2;
            this.chbLogInShowPassword.OnCheck.CheckBoxColor = System.Drawing.Color.White;
            this.chbLogInShowPassword.OnCheck.CheckmarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbLogInShowPassword.OnCheck.CheckmarkThickness = 5;
            this.chbLogInShowPassword.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chbLogInShowPassword.OnDisable.BorderRadius = 2;
            this.chbLogInShowPassword.OnDisable.BorderThickness = 2;
            this.chbLogInShowPassword.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chbLogInShowPassword.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chbLogInShowPassword.OnDisable.CheckmarkThickness = 2;
            this.chbLogInShowPassword.OnHoverChecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbLogInShowPassword.OnHoverChecked.BorderRadius = 2;
            this.chbLogInShowPassword.OnHoverChecked.BorderThickness = 2;
            this.chbLogInShowPassword.OnHoverChecked.CheckBoxColor = System.Drawing.Color.White;
            this.chbLogInShowPassword.OnHoverChecked.CheckmarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbLogInShowPassword.OnHoverChecked.CheckmarkThickness = 5;
            this.chbLogInShowPassword.OnHoverUnchecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbLogInShowPassword.OnHoverUnchecked.BorderRadius = 2;
            this.chbLogInShowPassword.OnHoverUnchecked.BorderThickness = 2;
            this.chbLogInShowPassword.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.White;
            this.chbLogInShowPassword.OnUncheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.chbLogInShowPassword.OnUncheck.BorderRadius = 2;
            this.chbLogInShowPassword.OnUncheck.BorderThickness = 2;
            this.chbLogInShowPassword.OnUncheck.CheckBoxColor = System.Drawing.Color.White;
            this.chbLogInShowPassword.Size = new System.Drawing.Size(35, 35);
            this.chbLogInShowPassword.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chbLogInShowPassword.TabIndex = 46;
            this.chbLogInShowPassword.ThreeState = false;
            this.chbLogInShowPassword.ToolTipText = null;
            this.chbLogInShowPassword.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.chbLogInShowPassword_CheckedChanged);
            // 
            // btnLogIn
            // 
            this.btnLogIn.AnimationHoverSpeed = 0.7F;
            this.btnLogIn.AnimationSpeed = 0.7F;
            this.btnLogIn.BackColor = System.Drawing.Color.Transparent;
            this.btnLogIn.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.btnLogIn.BorderColor = System.Drawing.Color.Black;
            this.btnLogIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogIn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnLogIn.FocusedColor = System.Drawing.Color.Empty;
            this.btnLogIn.Font = new System.Drawing.Font("Lucida Sans Unicode", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogIn.ForeColor = System.Drawing.Color.White;
            this.btnLogIn.Image = null;
            this.btnLogIn.ImageSize = new System.Drawing.Size(20, 20);
            this.btnLogIn.Location = new System.Drawing.Point(487, 519);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(35)))), ((int)(((byte)(76)))));
            this.btnLogIn.OnHoverBorderColor = System.Drawing.Color.White;
            this.btnLogIn.OnHoverForeColor = System.Drawing.Color.White;
            this.btnLogIn.OnHoverImage = null;
            this.btnLogIn.OnPressedColor = System.Drawing.Color.Black;
            this.btnLogIn.Radius = 30;
            this.btnLogIn.Size = new System.Drawing.Size(495, 76);
            this.btnLogIn.TabIndex = 48;
            this.btnLogIn.Text = "Log In";
            this.btnLogIn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Consolas", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.label4.Location = new System.Drawing.Point(459, 714);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(345, 33);
            this.label4.TabIndex = 49;
            this.label4.Text = "Don\'t have an account?";
            // 
            // lblGoSignUp
            // 
            this.lblGoSignUp.AutoSize = true;
            this.lblGoSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblGoSignUp.Font = new System.Drawing.Font("Consolas", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoSignUp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(26)))), ((int)(((byte)(74)))));
            this.lblGoSignUp.Location = new System.Drawing.Point(839, 699);
            this.lblGoSignUp.Name = "lblGoSignUp";
            this.lblGoSignUp.Size = new System.Drawing.Size(190, 51);
            this.lblGoSignUp.TabIndex = 50;
            this.lblGoSignUp.Text = "Sign Up";
            this.lblGoSignUp.Click += new System.EventHandler(this.lblGoSignUp_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 811);
            this.Controls.Add(this.lblGoSignUp);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnLogIn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.chbLogInShowPassword);
            this.Controls.Add(this.txtLogInPassword);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtLogInEmailUsername);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.minimizeLogIn);
            this.Controls.Add(this.closeLogIn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panelSignUpLeft);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LogIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LogIn";
            this.Load += new System.EventHandler(this.LogIn_Load);
            this.panelSignUpLeft.ResumeLayout(false);
            this.panelSignUpLeft.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelSignUpLeft;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label minimizeLogIn;
        private System.Windows.Forms.Label closeLogIn;
        private System.Windows.Forms.Label label2;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtLogInPassword;
        private System.Windows.Forms.Label label6;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtLogInEmailUsername;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private Bunifu.UI.WinForms.BunifuCheckBox chbLogInShowPassword;
        private Guna.UI.WinForms.GunaButton btnLogIn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblGoSignUp;
        private System.Windows.Forms.Timer timer1;
    }
}