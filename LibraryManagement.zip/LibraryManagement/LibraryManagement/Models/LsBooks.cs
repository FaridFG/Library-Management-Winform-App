﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement.Models
{
    public class LsBooks
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public Nullable<int> Quantity { get; set; }

        public override string ToString()
        {
            return $"{Name} - {Quantity}";
        }
    }
}
