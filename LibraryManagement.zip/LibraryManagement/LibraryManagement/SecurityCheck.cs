﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement
{
    public static class SecurityCheck
    {
        public static bool isValidNameAndSurname(this string name)
        {
            if (name == "")
            {
                MyMsgBox msg = new MyMsgBox("Please, enter your name and surname.");
                msg.ShowDialog();
                return false;
            }
            string validityCheck = "~`!@#$%^&*()-+={}[]\\|:;\"'<>,_./?";
            foreach (char symbol in validityCheck)
            {
                if (name.Contains(symbol))
                {
                    MyMsgBox msg = new MyMsgBox("Please, enter a valid name and surname. Name and surname can contain only letters.");
                    msg.ShowDialog();
                    return false;
                }
            }
            return true;
        }

        public static bool isValidUsername(this string username)
        {
            if (username == "")
            {
                MyMsgBox msg = new MyMsgBox("You must enter a valid username!");
                msg.ShowDialog();
                return false;
            }

            string validityCheck = "~`!@#$%^&*()-+={}[]\\|:;\"'<>,./?";
            foreach (char symbol in validityCheck)
            {
                if (username.Contains(symbol))
                {
                    MyMsgBox msg = new MyMsgBox("Invalid username. Username can contain letters, numbers, and underscore(_) symbol");
                    msg.ShowDialog();
                    return false;
                }
            }
            return true;
        }

        public static bool isValidEmail(this string email)
        {
            if (email == "")
            {
                MyMsgBox msg = new MyMsgBox("You must enter a valid email for your account!");
                msg.ShowDialog();
                return false;
            }

            string validityCheck = "~`!@#$%^&*()-+={}[]\\|:;\"'<>_,/?";
            string mail = email.Substring(email.IndexOf('@') + 1);
            int count = 0;
            if (!email.Contains("@"))
            {
                MyMsgBox msg = new MyMsgBox("Invalid email address. Please, enter existing email address!");
                msg.ShowDialog();
                return false;
            }
            else if (!(mail.Contains(".")))
            {
                MyMsgBox msg = new MyMsgBox("Invalid email address. Please, enter existing email address!");
                msg.ShowDialog();
                return false;
            }
            else if (!(mail.Length >= 4))
            {
                MyMsgBox msg = new MyMsgBox("Invalid email address. Please, enter existing email address!");
                msg.ShowDialog();
                return false;
            }
            for (int i = 0; i < mail.Length; i++)
            {
                if (mail[i] == '.')
                {
                    count++;
                }
                if (mail[i] == '.' && mail[i - 1] == '.')
                {
                    MyMsgBox msg = new MyMsgBox("Invalid email address. Please, enter existing email address!");
                    msg.ShowDialog();
                    return false;
                }
            }
            if (count >= 2 && mail.Length <= 4)
            {
                MyMsgBox msg = new MyMsgBox("Invalid email address. Please, enter existing email address!");
                msg.ShowDialog();
                return false;
            }
            foreach (char symbol in validityCheck)
            {
                if (mail.Contains(symbol))
                {
                    MyMsgBox msg = new MyMsgBox("Invalid email address. Please, enter existing email address!");
                    msg.ShowDialog();
                    return false;
                }
            }
            string domain = mail.Substring(mail.LastIndexOf('.') + 1);
            if (domain.Length < 2)
            {
                MyMsgBox msg = new MyMsgBox("Invalid email address. Please, enter existing email address!");
                msg.ShowDialog();
                return false;
            }
            return true;
        }

        public static bool isValidPassword(this string password, string passConfirm)
        {
            if (password == "")
            {
                MyMsgBox msg = new MyMsgBox("You must enter a password for your account!");
                msg.ShowDialog();
                return false;
            }
            else if (password.Length < 6)
            {
                MyMsgBox msg = new MyMsgBox("Password must contain at least 6 symbols");
                msg.ShowDialog();
                return false;
            }
            else if (password != passConfirm)
            {
                MyMsgBox msg = new MyMsgBox("Password and its confirmation must be same");
                msg.ShowDialog();
                return false;
            }
            return true;
        }

        public static string HashPassword(this string password)
        {
            byte[] encodingPass = Encoding.ASCII.GetBytes(password);
            SHA256Managed hash = new SHA256Managed();
            byte[] hashPass = hash.ComputeHash(encodingPass);
            return Encoding.ASCII.GetString(hashPass);
        }
    }
}
