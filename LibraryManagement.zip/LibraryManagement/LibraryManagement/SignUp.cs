﻿using LibraryManagement.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagement
{
    public partial class SignUp : Form
    {
        private LibraryEntities _db;
        private Form _login;
        public SignUp(Form form)
        {
            InitializeComponent();
            _db = new LibraryEntities();
            _login = form;
        }

        private void SignUp_Load(object sender, EventArgs e)
        {
            txtSingUpPassword.UseSystemPasswordChar = true;
            txtSignUpPasswordConfirm.UseSystemPasswordChar = true;
        }

        private void closeSignUp_Click(object sender, EventArgs e)
        {
            this.Close();
            _login.Show();
        }

        private void minimizeSignUp_Click(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
        }

        private void btnSignUpCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void chbSignUpShowPassword_CheckedChanged(object sender, Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs e)
        {
            if (chbSignUpShowPassword.Checked)
            {
                txtSingUpPassword.UseSystemPasswordChar = false;
                txtSignUpPasswordConfirm.UseSystemPasswordChar = false;
            }
            else
            {
                txtSingUpPassword.UseSystemPasswordChar = true;
                txtSignUpPasswordConfirm.UseSystemPasswordChar = true;
            }
        }

        private async void btnSignUp_Click(object sender, EventArgs e)
        {
            string name = txtSignUpName.Text.Trim();
            string surname = txtSignUpSurname.Text.Trim();
            string email = txtSignUpEmail.Text.Trim();
            string username = txtSignUpUsername.Text.Trim();
            string password = txtSingUpPassword.Text.Trim();
            string passConfirm = txtSignUpPasswordConfirm.Text.Trim();

            if (name == "" && surname == "" && email == "" && username == "" && password == "" && passConfirm == "")
            {
                MyMsgBox msg = new MyMsgBox("Please, fill out all the fields!");
                msg.ShowDialog();
                return;
            }

            if (!name.isValidNameAndSurname())
            {
                return;
            }
            
            if (!surname.isValidNameAndSurname())
            {
                return;
            }
            
            if (!email.isValidEmail())
            {
                return;
            }
            
            if (!username.isValidUsername())
            {
                return;
            }
            
            if (!password.isValidPassword(passConfirm))
            {
                return;
            }

            if (!chbAgreeTerms.Checked)
            {
                MyMsgBox msg = new MyMsgBox("You must agree with terms and conditions of our Company!");
                msg.ShowDialog();
                return;
            }

            if (_db.Employees.Any(em => em.Email == email))
            {
                MyMsgBox msg = new MyMsgBox("We are sorry, but this email is already exists!");
                msg.ShowDialog();
                return;
            }

            if (_db.Employees.Any(em => em.Username == username))
            {
                MyMsgBox msg = new MyMsgBox("We are sorry, but this username is already exists!");
                msg.ShowDialog();
                return;
            }

            Employee employee = new Employee() { Name = name, Surname = surname, Email = email, Username = username, Password = password.HashPassword() };
            _db.Employees.Add(employee);
            await _db.SaveChangesAsync();

            MyMsgBox message = new MyMsgBox("Congratulations! You have successfully signed up!");
            message.ShowDialog();

            txtSignUpName.Text = "";
            txtSignUpSurname.Text = "";
            txtSignUpEmail.Text = "";
            txtSignUpUsername.Text = "";
            txtSingUpPassword.Text = "";
            txtSignUpPasswordConfirm.Text = "";
        }
    }
}
